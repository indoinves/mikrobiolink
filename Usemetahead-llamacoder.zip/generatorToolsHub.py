#!/usr/bin/env python3
"""
generatorToolsHub.py
Auto-generates the MicroBioLink Tools Hub:
  - creates folder structure under ./generated/tools/<category>/<slug>/
  - writes an index.html per tool (SEO + AdSense meta injected silently)
  - writes a tools.json manifest consumed by the React app
  - writes sitemap.xml, robots.txt, ads.txt, app-ads.txt
  - writes a manifest.json (PWA) for Android / iOS / Web install

Usage:
    python3 generatorToolsHub.py
    python3 generatorToolsHub.py --out ./generated --base https://microbiolink.app
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
ADSENSE_PUB = "ca-pub-6718454554209533"
ADSENSE_ADS_TXT = "google.com, pub-6718454554209533, DIRECT, f08c47fec0942fa0"

GOOGLE_VERIFICATIONS = [
    "_cIzXXc36JQpFAdNi1A8HnhUc-5lEb3AxlbNyJiK2ZU",
    "QT96Rd0InOuqkb4s1Wu5BlgGD_pCNOy8CsCtveF1zEA",
    "e1adJE3Uadivc1NAhHfSiG1YcUSbTFCJ0gQ9T4nDj_U",
]
MSVALIDATE = "A6BC1DD96D711E50BC95B39A1FA4C33E"

TOOL_CATEGORIES = {
    "SEO": ["Keyword Density", "Meta Tag Generator", "SERP Preview", "Backlink Checker",
            "Robots.txt Builder", "Sitemap Generator", "Schema Markup", "Page Speed Audit",
            "Canonical Helper", "Open Graph Tester"],
    "Text": ["Word Counter", "Case Converter", "Lorem Ipsum", "Plagiarism Scan",
             "Readability Score", "Text Diff", "Remove Duplicates", "Slug Generator",
             "Markdown Editor", "Grammar Fix"],
    "Image": ["Image Compressor", "Resize Image", "Crop Tool", "Format Converter",
              "Background Remover", "Watermark Adder", "Color Picker", "Favicon Maker",
              "Image to Base64", "SVG Optimizer"],
    "Developer": ["JSON Formatter", "Base64 Encode", "URL Encode", "Regex Tester",
                  "JWT Decoder", "UUID Generator", "Hash Generator", "Cron Parser",
                  "HTML Minifier", "CSS Minifier"],
    "Converter": ["Unit Converter", "Currency Converter", "Time Zone", "Number to Words",
                  "Binary Converter", "Hex Converter", "PDF to Word", "Word to PDF",
                  "CSV to JSON", "YAML to JSON"],
    "Security": ["Password Generator", "Password Strength", "SSL Checker", "IP Lookup",
                 "DNS Lookup", "Whois Lookup", "Port Scanner", "Encryption Tool",
                 "2FA Generator", "Breach Check"],
    "Social": ["Hashtag Generator", "Bio Generator", "Post Scheduler", "Engagement Calc",
               "Username Check", "Emoji Picker", "QR Generator", "Link Shortener",
               "UTM Builder", "Social Preview"],
    "Finance": ["Loan Calculator", "Compound Interest", "Tax Estimator", "Invoice Maker",
                "Profit Margin", "Break-even Calc", "ROI Calculator", "Salary Converter",
                "Tip Calculator", "Mortgage Calc"],
    "Utility": ["QR Scanner", "Barcode Gen", "Random Picker", "Stopwatch", "Timer",
                "Calendar", "Notes", "Todo List", "Clipboard", "Screen Ruler"],
    "AI": ["AI Writer", "AI Summarizer", "AI Translator", "AI Chat", "AI Image Gen",
           "AI Code Helper", "AI SEO Advisor", "AI Caption", "AI Voice", "AI Sentiment"],
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text.strip("-")


def head_block(title: str, description: str, canonical: str) -> str:
    """Full <head> meta — AdSense pub id lives ONLY here, never in visible text."""
    verif = "\n".join(
        f'<meta name="google-site-verification" content="{v}" />' for v in GOOGLE_VERIFICATIONS
    )
    return f"""<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>{title}</title>
<meta name="description" content="{description}" />
<meta name="robots" content="index, follow" />
<link rel="canonical" href="{canonical}" />
{verif}
<meta name="msvalidate.01" content="{MSVALIDATE}" />
<meta name="google-adsense-account" content="{ADSENSE_PUB}" />
<meta property="og:title" content="{title}" />
<meta property="og:description" content="{description}" />
<meta property="og:type" content="website" />
<meta property="og:url" content="{canonical}" />
<meta name="twitter:card" content="summary_large_image" />
<link rel="icon" type="image/png" href="/favicon.png" />
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
<link rel="apple-touch-icon" href="/icon-192.png" />
<link rel="manifest" href="/manifest.json" />
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADSENSE_PUB}" crossorigin="anonymous"></script>
<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>
</head>"""


def tool_page_html(tool_name: str, category: str, slug: str, base: str) -> str:
    canonical = f"{base}/tools/{slugify(category)}/{slug}/"
    desc = f"{tool_name} — free online {category.lower()} tool. Fast, private, works in your browser."
    return f"""<!doctype html>
<html lang="en">
{head_block(f"{tool_name} — Free Online Tool | MicroBioLink", desc, canonical)}
<body>
<div id="root" data-tool="{tool_name}" data-category="{category}"></div>
<noscript>
  <h1>{tool_name}</h1>
  <p>{desc}</p>
</noscript>
<script type="module" src="/assets/app.js"></script>
</body>
</html>
"""


def hub_page_html(base: str, tools: list) -> str:
    canonical = f"{base}/tools/"
    cards = "\n".join(
        f'    <li><a href="/tools/{slugify(t["category"])}/{t["slug"]}/">{t["name"]}</a> '
        f'<span>{t["category"]}</span></li>'
        for t in tools
    )
    return f"""<!doctype html>
<html lang="en">
{head_block("Tools Hub — 100 Free Online Tools | MicroBioLink",
            "Browse 100 free online tools: SEO, text, image, developer, converter, security, social, finance, utility and AI.",
            canonical)}
<body>
<main>
  <h1>Tools Hub</h1>
  <p>{len(tools)} free tools, all running in your browser.</p>
  <ul>
{cards}
  </ul>
</main>
</body>
</html>
"""


def write(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


# ---------------------------------------------------------------------------
# Main generator
# ---------------------------------------------------------------------------
def generate(out_dir: str, base: str) -> dict:
    tools = []
    idx = 0
    for category, names in TOOL_CATEGORIES.items():
        for name in names:
            slug = slugify(name)
            tools.append({
                "id": f"tool-{idx}",
                "name": name,
                "category": category,
                "slug": slug,
                "desc": f"{name} — powerful {category.lower()} tool for creators and developers.",
                "url": f"/tools/{slugify(category)}/{slug}/",
            })
            idx += 1

    # per-tool pages
    for t in tools:
        page = tool_page_html(t["name"], t["category"], t["slug"], base)
        write(os.path.join(out_dir, "tools", slugify(t["category"]), t["slug"], "index.html"), page)

    # hub page
    write(os.path.join(out_dir, "tools", "index.html"), hub_page_html(base, tools))

    # manifest for the React app
    write(os.path.join(out_dir, "tools.json"), json.dumps(tools, indent=2, ensure_ascii=False))

    # sitemap
    urls = [f"{base}/", f"{base}/tools/"] + [f"{base}{t['url']}" for t in tools]
    sitemap = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u in urls:
        sitemap.append(f"  <url><loc>{u}</loc></url>")
    sitemap.append("</urlset>")
    write(os.path.join(out_dir, "sitemap.xml"), "\n".join(sitemap))

    # robots.txt
    write(os.path.join(out_dir, "robots.txt"),
          f"User-agent: *\nAllow: /\nDisallow: /admin/\nSitemap: {base}/sitemap.xml\n")

    # ads.txt + app-ads.txt (publisher line only — never rendered in UI)
    write(os.path.join(out_dir, "ads.txt"), ADSENSE_ADS_TXT + "\n")
    write(os.path.join(out_dir, "app-ads.txt"), ADSENSE_ADS_TXT + "\n")

    # PWA manifest (Web / Android / iOS)
    manifest = {
        "name": "MicroBioLink",
        "short_name": "MicroBioLink",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#0f172a",
        "theme_color": "#4f46e5",
        "icons": [
            {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
            {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png"},
        ],
    }
    write(os.path.join(out_dir, "manifest.json"), json.dumps(manifest, indent=2))

    return {"count": len(tools), "categories": len(TOOL_CATEGORIES), "out": out_dir}


def main() -> int:
    ap = argparse.ArgumentParser(description="Generate the MicroBioLink Tools Hub.")
    ap.add_argument("--out", default="./generated", help="output directory")
    ap.add_argument("--base", default="https://microbiolink.app", help="site base URL")
    args = ap.parse_args()

    result = generate(args.out, args.base)
    print(f"[{datetime.now(timezone.utc).isoformat()}] "
          f"Generated {result['count']} tools across {result['categories']} categories -> {result['out']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())