#!/usr/bin/env python3
"""
Bio Link Blog Generator — Cloudflare Pages ready.

Generates 100 SEO-optimized blog posts across 10 labels into ./public/blog/posts/
plus an index, sitemap, robots.txt, manifest, and service worker.

Usage:
    python3 public/blog/generator/blog.py           # generate everything
    python3 public/blog/generator/blog.py --clean   # wipe output first

Cloudflare Pages build command:
    python3 public/blog/generator/blog.py
Build output directory:
    public
"""

import os
import re
import json
import shutil
import argparse
from datetime import datetime, timedelta
from html import escape

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------

SITE_NAME = "Bio Link"
SITE_URL = "https://microbiolink.app"
ADSENSE_CLIENT = "ca-pub-6718454554209533"
GOOGLE_VERIFICATIONS = [
    "_cIzXXc36JQpFAdNi1A8HnhUc-5lEb3AxlbNyJiK2ZU",
    "QT96Rd0InOuqkb4s1Wu5BlgGD_pCNOy8CsCtveF1zEA",
    "e1adJE3Uadivc1NAhHfSiG1YcUSbTFCJ0gQ9T4nDj_U",
]
MSVALIDATE = "A6BC1DD96D711E50BC95B39A1FA4C33E"

# Resolve project root (…/public) from this file's location
HERE = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.abspath(os.path.join(HERE, "..", ".."))
BLOG_DIR = os.path.join(PUBLIC_DIR, "blog")
POSTS_DIR = os.path.join(BLOG_DIR, "posts")

LABELS = [
    "Creator Tips",
    "AI & Automation",
    "SEO & Growth",
    "Monetization",
    "Design & Themes",
    "Email Marketing",
    "Analytics",
    "Custom Domains",
    "Product Updates",
    "Case Studies",
]

POST_TITLES = {
    "Creator Tips": [
        "10 Ways to Grow Your Audience with a Link-in-Bio Page",
        "How to Build a Personal Brand That Stands Out",
        "The Creator's Guide to Content Repurposing",
        "5 Habits of Highly Successful Creators",
        "How to Turn Followers into Superfans",
        "Building Trust with Your Audience Online",
        "The Ultimate Checklist for New Creators",
        "How to Find Your Niche as a Creator",
        "Networking Tips for Digital Creators",
        "From Hobby to Full-Time Creator: A Roadmap",
    ],
    "AI & Automation": [
        "How AI Assistants Boost Creator Engagement",
        "Automating Your Content Workflow with AI",
        "AI Chatbots: The Future of Fan Interaction",
        "Training an AI on Your Brand Voice",
        "5 AI Tools Every Creator Should Know",
        "How to Use AI to Write Better Captions",
        "AI-Powered Personalization for Bio Pages",
        "The Ethics of AI in Content Creation",
        "AI vs Human: Finding the Right Balance",
        "Automate Your Email Replies with AI",
    ],
    "SEO & Growth": [
        "SEO Basics Every Creator Must Know",
        "How to Rank Your Bio Page on Google",
        "Keyword Research for Content Creators",
        "The Complete Guide to On-Page SEO",
        "Building Backlinks as a Creator",
        "How to Write Meta Descriptions That Convert",
        "Structured Data: The Secret SEO Weapon",
        "Local SEO Tips for Creator Businesses",
        "How to Improve Your Page Speed Score",
        "The Ultimate SEO Checklist for 2025",
    ],
    "Monetization": [
        "7 Ways to Monetize Your Bio Link",
        "How to Sell Digital Products Online",
        "Setting Up Affiliate Links the Right Way",
        "Building a Paid Membership Community",
        "How to Price Your Digital Products",
        "Selling Sponsorships: A Creator's Guide",
        "From Free to Paid: Transitioning Your Audience",
        "Passive Income Ideas for Creators",
        "How to Launch a Course from Your Bio Link",
        "Tips for Selling Physical Merch Online",
    ],
    "Design & Themes": [
        "Choosing the Perfect Theme for Your Bio Page",
        "Color Psychology in Creator Branding",
        "Typography Tips for Beautiful Bio Pages",
        "How to Design a Mobile-First Bio Page",
        "10 Stunning Bio Link Theme Ideas",
        "Using Images to Boost Engagement",
        "The Art of Minimalist Bio Page Design",
        "Custom CSS Tricks for Bio Pages",
        "Designing for Accessibility: A Guide",
        "How to Create a Cohesive Visual Identity",
    ],
    "Email Marketing": [
        "Why Every Creator Needs an Email List",
        "How to Grow Your Email List Fast",
        "Writing Welcome Emails That Convert",
        "The Anatomy of a Perfect Newsletter",
        "Email Segmentation for Better Engagement",
        "How to Avoid the Spam Folder",
        "Re-engagement Campaigns That Work",
        "Building Automated Email Sequences",
        "A/B Testing Your Email Subject Lines",
        "Turning Subscribers into Customers",
    ],
    "Analytics": [
        "Understanding Your Bio Page Analytics",
        "Key Metrics Every Creator Should Track",
        "How to Use Data to Improve Engagement",
        "Setting Up Conversion Tracking",
        "The Difference Between Views and Clicks",
        "How to Read a Traffic Report",
        "A/B Testing Your Bio Page Links",
        "Tracking ROI on Your Content",
        "Building a Creator Dashboard",
        "Using Heatmaps to Optimize Your Page",
    ],
    "Custom Domains": [
        "Why You Need a Custom Domain",
        "How to Connect Your Domain to Bio Link",
        "Choosing the Best Domain Name",
        "DNS Explained for Creators",
        "SSL Certificates: What You Need to Know",
        "Migrating from a Subdomain to a Custom Domain",
        "Domain Privacy and Security Tips",
        "How Custom Domains Boost Credibility",
        "Managing Multiple Domains",
        "The Cost of Owning a Domain",
    ],
    "Product Updates": [
        "Introducing AI Chat for Every Creator",
        "New Theme Editor: What's Changed",
        "Bio Link Analytics Just Got Better",
        "Announcing Custom Domain Support",
        "The New Email List Builder Is Here",
        "Faster Page Loads in the Latest Update",
        "Introducing QR Code Sharing",
        "New Integrations: Spotify, YouTube, and More",
        "Improved Mobile Editor Experience",
        "What's New in Bio Link This Month",
    ],
    "Case Studies": [
        "How a Musician Grew 10x with Bio Link",
        "From Zero to 100K Followers: A Case Study",
        "How a Coach Built a 6-Figure Business",
        "A Photographer's Journey to Full-Time",
        "How a Podcaster Doubled Downloads",
        "Building a Fitness Brand with Bio Link",
        "How an Artist Sold Out a Collection",
        "A Nonprofit's Success Story",
        "How a Chef Grew a Loyal Community",
        "From Side Hustle to Main Income",
    ],
}

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

def slugify(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"\s+", "-", text.strip())
    return re.sub(r"-+", "-", text)


def read_time(body):
    return max(1, round(len(body.split()) / 200))


def build_body(title, label, index):
    intro = (
        f'<p class="lead">In the fast-moving world of online creators, staying ahead means '
        f'mastering the tools and strategies that actually move the needle. This article, '
        f'part of our <strong>{escape(label)}</strong> series, breaks down everything you '
        f'need to know about <em>{escape(title.lower())}</em> — with practical steps you can '
        f'apply today.</p>'
    )
    sections = [
        ("Why this matters",
         f"Creators who understand {escape(label.lower())} consistently outperform those who "
         f"don't. Whether you're just starting out or scaling an established audience, the "
         f"principles below will help you build a stronger, more resilient presence online."),
        ("Getting started",
         "The first step is always the simplest: audit what you already have. Look at your "
         "bio link, your content calendar, and your analytics. Identify the gaps, then apply "
         "the tactics in this guide one at a time. Small, consistent improvements compound "
         "into massive results over months, not days."),
        ("Best practices",
         "Keep your messaging clear, your design consistent, and your calls-to-action "
         "obvious. Test everything — from the wording of a button to the color of a link. "
         "Your audience will tell you what works if you pay attention to the data."),
        ("Common mistakes to avoid",
         "Don't try to do everything at once. Don't copy competitors blindly. And don't "
         "ignore your analytics. The creators who win are the ones who iterate based on "
         "real feedback, not assumptions."),
        ("Putting it into action",
         "Pick one tactic from this article and implement it this week. Measure the result. "
         "Then pick another. That's how you turn knowledge into growth — one deliberate step "
         "at a time."),
    ]
    body = intro
    for h, p in sections:
        body += f"<h2>{escape(h)}</h2><p>{p}</p>"
    body += (
        '<blockquote>"The best time to start was yesterday. The second best time is now."'
        "</blockquote>"
        '<p>Ready to put these ideas to work? <a href="/#signup">Claim your free Bio Link '
        "page</a> and start building today.</p>"
    )
    return body


def verification_block():
    lines = []
    for v in GOOGLE_VERIFICATIONS:
        lines.append(f'<meta name="google-site-verification" content="{v}" />')
    lines.append(f'<meta name="msvalidate.01" content="{MSVALIDATE}" />')
    lines.append(f'<meta name="google-adsense-account" content="{ADSENSE_CLIENT}" />')
    lines.append(
        f'<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADSENSE_CLIENT}" crossorigin="anonymous"></script>'
    )
    lines.append(
        '<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>'
    )
    return "\n    ".join(lines)


def meta_block(title, description, url, image, published, modified, label, author="Bio Link Team"):
    return f"""
    <meta property="og:type" content="article" />
    <meta property="og:site_name" content="{SITE_NAME}" />
    <meta property="og:title" content="{escape(title)}" />
    <meta property="og:description" content="{escape(description)}" />
    <meta property="og:url" content="{url}" />
    <meta property="og:image" content="{image}" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:locale" content="en_US" />
    <meta property="article:published_time" content="{published}" />
    <meta property="article:modified_time" content="{modified}" />
    <meta property="article:section" content="{escape(label)}" />
    <meta property="article:author" content="{escape(author)}" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@biolink" />
    <meta name="twitter:title" content="{escape(title)}" />
    <meta name="twitter:description" content="{escape(description)}" />
    <meta name="twitter:image" content="{image}" />
    """


def jsonld_article(title, description, url, image, published, modified, label, author="Bio Link Team"):
    data = {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": title,
        "description": description,
        "image": image,
        "datePublished": published,
        "dateModified": modified,
        "author": {"@type": "Organization", "name": author},
        "publisher": {
            "@type": "Organization",
            "name": SITE_NAME,
            "logo": {"@type": "ImageObject", "url": f"{SITE_URL}/icon-192.png"},
        },
        "mainEntityOfPage": {"@type": "WebPage", "@id": url},
        "articleSection": label,
    }
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# TEMPLATES
# ---------------------------------------------------------------------------

HEAD_COMMON = """<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<meta name="theme-color" content="#4f46e5" />
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-title" content="Bio Link" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="msapplication-TileColor" content="#4f46e5" />
<link rel="icon" type="image/png" href="/favicon.png" />
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
<link rel="apple-touch-icon" href="/icon-192.png" />
<link rel="manifest" href="/manifest.json" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap" rel="stylesheet" />"""

STYLE = """
:root{--ink:#0b1220;--ink-2:#1e293b;--muted:#64748b;--brand:#4f46e5;--accent:#0d9488;--amber:#f59e0b;--rose:#e11d48;--bg:#f8fafc;--card:#fff;--line:#e2e8f0;--radius:20px;--shadow-sm:0 1px 2px rgba(15,23,42,.06),0 1px 3px rgba(15,23,42,.05);--shadow-md:0 4px 12px rgba(15,23,42,.07);--shadow-lg:0 24px 48px -12px rgba(30,27,75,.22)}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}
body{font-family:"Plus Jakarta Sans",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:var(--bg);color:var(--ink);line-height:1.7;-webkit-font-smoothing:antialiased}
.serif{font-family:"Fraunces",Georgia,serif;letter-spacing:-.02em}
a{color:inherit;text-decoration:none}
img{max-width:100%;display:block}
.wrap{width:100%;max-width:1200px;margin:0 auto;padding:0 20px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;font-weight:600;font-size:.95rem;padding:12px 22px;border-radius:999px;border:1px solid transparent;cursor:pointer;transition:.2s ease;white-space:nowrap;font-family:inherit}
.btn-primary{background:var(--brand);color:#fff;box-shadow:0 8px 20px -6px rgba(79,70,229,.5)}
.btn-primary:hover{background:#4338ca;transform:translateY(-2px)}
.btn-outline{background:#fff;color:var(--ink);border-color:var(--line)}
.btn-outline:hover{border-color:var(--brand);color:var(--brand)}
.chip{display:inline-flex;align-items:center;gap:6px;font-size:.75rem;font-weight:600;padding:6px 12px;border-radius:999px;background:#eef2ff;color:var(--brand)}
header{position:sticky;top:0;z-index:50;background:rgba(248,250,252,.85);backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
.nav{display:flex;align-items:center;justify-content:space-between;height:68px;gap:16px}
.logo{display:flex;align-items:center;gap:10px;font-weight:800;font-size:1.15rem}
.logo-mark{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(135deg,var(--brand),var(--accent));color:#fff;box-shadow:0 8px 18px -6px rgba(79,70,229,.6)}
.logo-mark svg{width:20px;height:20px}
.nav-links{display:flex;align-items:center;gap:26px}
.nav-links a{font-size:.9rem;font-weight:500;color:var(--ink-2);transition:.2s}
.nav-links a:hover{color:var(--brand)}
.nav-cta{display:flex;align-items:center;gap:10px}
.nav-cta .link{font-size:.9rem;font-weight:600;color:var(--ink-2);padding:8px 6px}
.nav-cta .link:hover{color:var(--brand)}
.burger{display:none;width:42px;height:42px;border-radius:12px;border:1px solid var(--line);background:#fff;cursor:pointer;place-items:center}
.burger span{display:block;width:18px;height:2px;background:var(--ink);border-radius:2px;position:relative}
.burger span::before,.burger span::after{content:"";position:absolute;left:0;width:18px;height:2px;background:var(--ink);border-radius:2px}
.burger span::before{top:-6px}.burger span::after{top:6px}
.mobile-menu{display:none;flex-direction:column;gap:4px;padding:12px 20px 20px;border-bottom:1px solid var(--line);background:#fff}
.mobile-menu a{padding:12px 8px;font-weight:600;border-radius:10px}
.mobile-menu a:hover{background:#f1f5f9}
.mobile-menu.open{display:flex}
section{padding:60px 0}
.hero-blog{background:radial-gradient(900px 500px at 15% -10%,#4338ca 0%,transparent 55%),radial-gradient(700px 400px at 90% 10%,#0d9488 0%,transparent 50%),linear-gradient(160deg,#0b1220 0%,#141b34 60%,#0b1220 100%);color:#fff;padding:64px 0 72px;position:relative;overflow:hidden}
.hero-blog::after{content:"";position:absolute;inset:0;opacity:.3;pointer-events:none;background-image:radial-gradient(rgba(255,255,255,.14) 1px,transparent 1px);background-size:26px 26px}
.hero-blog .wrap{position:relative;z-index:2}
.hero-blog h1{font-size:clamp(2rem,4.5vw,3rem);line-height:1.1;font-weight:700;margin:16px 0 14px}
.hero-blog p{color:rgba(255,255,255,.8);max-width:620px;font-size:1.05rem}
.blog-layout{display:grid;grid-template-columns:1fr 320px;gap:44px;align-items:start}
.post-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:22px}
.post-card{background:#fff;border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow-sm);transition:.25s;display:flex;flex-direction:column}
.post-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-md);border-color:#cbd5e1}
.post-thumb{height:170px;background:linear-gradient(135deg,#4f46e5,#0d9488);position:relative;overflow:hidden;display:grid;place-items:center;color:#fff;font-size:2.4rem;font-weight:800;font-family:"Fraunces",serif}
.post-thumb.t2{background:linear-gradient(135deg,#0d9488,#5eead4)}
.post-thumb.t3{background:linear-gradient(135deg,#e11d48,#fb7185)}
.post-thumb.t4{background:linear-gradient(135deg,#f59e0b,#fcd34d)}
.post-thumb.t5{background:linear-gradient(135deg,#7c3aed,#c4b5fd)}
.post-thumb.t6{background:linear-gradient(135deg,#0b1220,#334155)}
.post-body{padding:20px;flex:1;display:flex;flex-direction:column}
.post-label{font-size:.7rem;font-weight:800;color:var(--brand);text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px}
.post-card h3{font-size:1.05rem;font-weight:700;line-height:1.35;margin-bottom:10px}
.post-card h3 a:hover{color:var(--brand)}
.post-card p{font-size:.85rem;color:var(--muted);margin-bottom:14px;flex:1}
.post-meta{display:flex;align-items:center;gap:10px;font-size:.75rem;color:var(--muted);border-top:1px solid var(--line);padding-top:12px}
.post-meta .dot{width:4px;height:4px;border-radius:50%;background:var(--muted)}
.sidebar{position:sticky;top:88px;display:flex;flex-direction:column;gap:22px}
.widget{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:22px;box-shadow:var(--shadow-sm)}
.widget h4{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--ink);margin-bottom:14px;display:flex;align-items:center;gap:8px}
.widget h4::before{content:"";width:4px;height:16px;background:var(--brand);border-radius:2px}
.widget ul{list-style:none;display:flex;flex-direction:column;gap:10px}
.widget ul li a{font-size:.88rem;color:var(--ink-2);display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px dashed var(--line);transition:.2s}
.widget ul li:last-child a{border-bottom:0}
.widget ul li a:hover{color:var(--brand);padding-left:4px}
.widget ul li a span{color:var(--muted);font-size:.78rem;flex-shrink:0}
.popular-item{display:flex;gap:12px;padding:10px 0;border-bottom:1px dashed var(--line)}
.popular-item:last-child{border-bottom:0}
.popular-num{width:26px;height:26px;border-radius:8px;background:#eef2ff;color:var(--brand);display:grid;place-items:center;font-size:.75rem;font-weight:800;flex-shrink:0}
.popular-item a{font-size:.85rem;font-weight:600;line-height:1.4}
.popular-item a:hover{color:var(--brand)}
.newsletter{background:linear-gradient(135deg,#4f46e5,#0d9488);color:#fff;border:0}
.newsletter h4{color:#fff}
.newsletter h4::before{background:#fff}
.newsletter p{font-size:.85rem;color:rgba(255,255,255,.85);margin-bottom:14px}
.newsletter input{width:100%;border:0;border-radius:10px;padding:11px 14px;font-size:.88rem;font-family:inherit;margin-bottom:10px;outline:none}
.newsletter .btn{width:100%;background:#fff;color:var(--brand)}
.article{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:44px;box-shadow:var(--shadow-sm)}
.article h1{font-size:clamp(1.7rem,3.4vw,2.4rem);line-height:1.15;font-weight:700;margin:14px 0 16px}
.article .lead{font-size:1.08rem;color:var(--ink-2);margin-bottom:24px}
.article h2{font-size:1.35rem;font-weight:700;margin:32px 0 12px;color:var(--ink)}
.article p{margin-bottom:16px;color:var(--ink-2)}
.article blockquote{border-left:4px solid var(--brand);background:#f8fafc;padding:18px 22px;border-radius:0 12px 12px 0;font-style:italic;color:var(--ink-2);margin:24px 0}
.article a{color:var(--brand);font-weight:600}
.article a:hover{text-decoration:underline}
.article-meta{display:flex;align-items:center;gap:14px;flex-wrap:wrap;font-size:.82rem;color:var(--muted);padding-bottom:20px;border-bottom:1px solid var(--line);margin-bottom:24px}
.article-meta .author{display:flex;align-items:center;gap:8px}
.article-meta .author .ca{width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--brand),var(--accent));color:#fff;display:grid;place-items:center;font-size:.7rem;font-weight:800}
.share{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:32px 0;padding:20px;background:#f8fafc;border-radius:14px;border:1px solid var(--line)}
.share b{font-size:.85rem;margin-right:6px}
.share a{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border-radius:999px;background:#fff;border:1px solid var(--line);font-size:.82rem;font-weight:600;transition:.2s}
.share a:hover{border-color:var(--brand);color:var(--brand);transform:translateY(-2px)}
.breadcrumb{font-size:.82rem;color:var(--muted);margin-bottom:14px}
.breadcrumb a{color:var(--brand);font-weight:600}
.breadcrumb a:hover{text-decoration:underline}
.ad{border:1px dashed #cbd5e1;border-radius:16px;background:#fff;padding:18px;text-align:center;color:#94a3b8;font-size:.75rem;letter-spacing:.1em;text-transform:uppercase;margin:24px 0}
footer{background:#0b1220;color:#94a3b8;padding:60px 0 30px;margin-top:20px}
.foot-grid{display:grid;grid-template-columns:1.6fr 1fr 1fr 1fr;gap:36px}
footer h4{color:#fff;font-size:.82rem;text-transform:uppercase;letter-spacing:.1em;margin-bottom:16px}
footer a{display:block;font-size:.88rem;padding:5px 0;transition:.2s}
footer a:hover{color:#fff}
.foot-brand{display:flex;align-items:center;gap:10px;color:#fff;font-weight:800;font-size:1.1rem;margin-bottom:14px}
.foot-bottom{border-top:1px solid #1e293b;margin-top:44px;padding-top:24px;display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;font-size:.82rem}
.cookie{position:fixed;left:20px;right:20px;bottom:20px;z-index:100;max-width:520px;background:#fff;border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:var(--shadow-lg);display:none;gap:14px;flex-direction:column}
.cookie.show{display:flex}
.cookie p{font-size:.85rem;color:var(--muted)}
.cookie b{color:var(--ink);font-size:.9rem;display:block;margin-bottom:4px}
.cookie-actions{display:flex;gap:10px;flex-wrap:wrap}
.cookie-actions .btn{padding:10px 18px;font-size:.85rem}
@media(max-width:960px){.blog-layout{grid-template-columns:1fr}.sidebar{position:static}.post-grid{grid-template-columns:1fr}.foot-grid{grid-template-columns:1fr 1fr}.nav-links{display:none}.nav-cta .link{display:none}.burger{display:grid}.article{padding:28px}}
@media(max-width:640px){section{padding:44px 0}.hero-blog{padding:44px 0 52px}.foot-grid{grid-template-columns:1fr}.article{padding:22px}.cookie{left:12px;right:12px;bottom:12px}}
"""

HEADER_HTML = """<header>
  <div class="wrap nav">
    <a class="logo" href="/">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></span>
      Bio Link
    </a>
    <nav class="nav-links">
      <a href="/#features">Features</a>
      <a href="/#pricing">Pricing</a>
      <a href="/blog/">Blog</a>
      <a href="/blog/#archive">Archive</a>
      <a href="/blog/#contact">Contact</a>
    </nav>
    <div class="nav-cta">
      <a class="link" href="/#login">Log in</a>
      <a class="btn btn-primary" href="/#signup">Sign up</a>
      <button class="burger" id="burger" aria-label="Menu"><span></span></button>
    </div>
  </div>
  <div class="mobile-menu" id="mobileMenu">
    <a href="/#features">Features</a>
    <a href="/#pricing">Pricing</a>
    <a href="/blog/">Blog</a>
    <a href="/blog/#archive">Archive</a>
    <a href="/blog/#contact">Contact</a>
    <a href="/#login">Log in</a>
  </div>
</header>"""

FOOTER_HTML = """<footer>
  <div class="wrap">
    <div class="foot-grid">
      <div>
        <div class="foot-brand"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></span>Bio Link</div>
        <p style="font-size:.88rem;max-width:280px">Your link-in-bio, now with a brain. Built for creators, everywhere.</p>
      </div>
      <div>
        <h4>Product</h4>
        <a href="/#features">Features</a>
        <a href="/#pricing">Pricing</a>
        <a href="/blog/">Blog</a>
        <a href="/#faq">FAQ</a>
      </div>
      <div>
        <h4>Company</h4>
        <a href="/about/">About</a>
        <a href="/contact/">Contact</a>
        <a href="/blog/#archive">Archive</a>
        <a href="/ads/">Advertising</a>
      </div>
      <div>
        <h4>Legal</h4>
        <a href="/privacy/">Privacy Policy</a>
        <a href="/disclaimer/">Disclaimer</a>
        <a href="/terms/">Terms of Service</a>
        <a href="/license/">License</a>
      </div>
    </div>
    <div class="foot-bottom">
      <span>© 2025 Bio Link. All rights reserved.</span>
      <span>Help Center · Terms of Use · Privacy Policy · Report · Meeting Notetaker</span>
    </div>
  </div>
</footer>"""

COOKIE_HTML = """<div class="cookie" id="cookie">
  <div>
    <b>We use cookies</b>
    <p>We use cookies to improve your experience, analyze traffic, and serve personalized ads. By clicking "Accept all", you consent to our use of cookies.</p>
  </div>
  <div class="cookie-actions">
    <button class="btn btn-primary" id="cookieAccept">Accept all</button>
    <button class="btn btn-outline" id="cookieReject">Reject</button>
    <a class="btn btn-outline" href="/privacy/">Learn more</a>
  </div>
</div>"""

SCRIPT_COMMON = """<script>
(function(){
  var b=document.getElementById('burger'),m=document.getElementById('mobileMenu');
  if(b&&m){b.addEventListener('click',function(){m.classList.toggle('open');});}
  var cookie=document.getElementById('cookie');
  var KEY='biolink_cookie_consent';
  try{if(!localStorage.getItem(KEY)&&cookie){cookie.classList.add('show');}}catch(e){if(cookie){cookie.classList.add('show');}}
  function dismiss(v){try{localStorage.setItem(KEY,v);}catch(e){}if(cookie){cookie.classList.remove('show');}}
  var a=document.getElementById('cookieAccept'),r=document.getElementById('cookieReject');
  if(a){a.addEventListener('click',function(){dismiss('accepted');});}
  if(r){r.addEventListener('click',function(){dismiss('rejected');});}
  if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register('/sw.js').catch(function(){});});}
})();
</script>"""


# ---------------------------------------------------------------------------
# BUILDERS
# ---------------------------------------------------------------------------

def build_post_page(title, label, body, published, modified, all_posts):
    slug = slugify(title)
    url = f"{SITE_URL}/blog/posts/{slug}.html"
    image = f"{SITE_URL}/og/{slug}.png"
    description = f"{title} — practical tips and strategies for creators. Part of our {label} series on Bio Link."
    rt = read_time(body)

    related = [p for p in all_posts if p["label"] == label and p["slug"] != slug][:3]
    related_html = "".join(
        f'<li><a href="/blog/posts/{p["slug"]}.html">{escape(p["title"])}<span>{p["read"]} min</span></a></li>'
        for p in related
    )

    popular = all_posts[:5]
    popular_html = "".join(
        f'<div class="popular-item"><span class="popular-num">{i+1}</span><a href="/blog/posts/{p["slug"]}.html">{escape(p["title"])}</a></div>'
        for i, p in enumerate(popular)
    )

    labels_count = {}
    for p in all_posts:
        labels_count[p["label"]] = labels_count.get(p["label"], 0) + 1
    archive_html = "".join(
        f'<li><a href="/blog/#{slugify(l)}">{escape(l)}<span>{c}</span></a></li>'
        for l, c in labels_count.items()
    )

    jsonld = jsonld_article(title, description, url, image, published, modified, label)
    meta = meta_block(title, description, url, image, published, modified, label)

    return slug, f"""<!doctype html>
<html lang="en">
<head>
{HEAD_COMMON}
<title>{escape(title)} — Bio Link Blog</title>
<meta name="description" content="{escape(description)}" />
<meta name="keywords" content="{escape(label.lower())}, bio link, creator tips, link in bio" />
<meta name="author" content="Bio Link Team" />
<link rel="canonical" href="{url}" />
{verification_block()}
{meta}
<script type="application/ld+json">
{jsonld}
</script>
<style>{STYLE}</style>
</head>
<body>
{HEADER_HTML}

<section class="hero-blog">
  <div class="wrap">
    <div class="breadcrumb" style="color:rgba(255,255,255,.7)"><a href="/" style="color:#a5b4fc">Home</a> › <a href="/blog/" style="color:#a5b4fc">Blog</a> › <span>{escape(label)}</span></div>
    <span class="chip" style="background:rgba(255,255,255,.14);color:#a5b4fc">{escape(label)}</span>
    <h1 class="serif">{escape(title)}</h1>
    <p>{escape(description)}</p>
  </div>
</section>

<section>
  <div class="wrap blog-layout">
    <article class="article">
      <div class="article-meta">
        <div class="author"><span class="ca">BL</span><b>Bio Link Team</b></div>
        <span>·</span><span>{published[:10]}</span><span>·</span><span>{rt} min read</span>
      </div>
      {body}
      <div class="ad">Advertisement</div>
      <div class="share">
        <b>Share this article:</b>
        <a href="https://twitter.com/intent/tweet?url={url}&text={escape(title)}" target="_blank" rel="noopener">Twitter</a>
        <a href="https://www.facebook.com/sharer/sharer.php?u={url}" target="_blank" rel="noopener">Facebook</a>
        <a href="https://www.linkedin.com/sharing/share-offsite/?url={url}" target="_blank" rel="noopener">LinkedIn</a>
        <a href="https://api.whatsapp.com/send?text={escape(title)}%20{url}" target="_blank" rel="noopener">WhatsApp</a>
        <a href="mailto:?subject={escape(title)}&body={url}">Email</a>
      </div>
      <h2>Related articles</h2>
      <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;margin-top:12px">{related_html}</ul>
    </article>
    <aside class="sidebar">
      <div class="widget"><h4>Popular posts</h4>{popular_html}</div>
      <div class="widget"><h4>Archive</h4><ul>{archive_html}</ul></div>
      <div class="widget newsletter">
        <h4>Join the newsletter</h4>
        <p>Get creator tips, product updates, and growth strategies in your inbox.</p>
        <form onsubmit="return false"><input type="email" placeholder="you@example.com" /><button class="btn" type="submit">Subscribe</button></form>
      </div>
      <div class="widget">
        <h4>Contact</h4>
        <p style="font-size:.85rem;color:var(--muted);margin-bottom:10px">Questions? We'd love to hear from you.</p>
        <a class="btn btn-outline" href="/contact/" style="width:100%">Contact us</a>
      </div>
    </aside>
  </div>
</section>

{FOOTER_HTML}
{COOKIE_HTML}
{SCRIPT_COMMON}
</body>
</html>"""


def build_index_page(all_posts):
    url = f"{SITE_URL}/blog/"
    image = f"{SITE_URL}/og/blog.png"
    title = "Bio Link Blog — Creator Tips, AI, SEO & Growth"
    description = "100+ articles on creator growth, AI automation, SEO, monetization, design, email marketing, analytics, and custom domains."

    cards = ""
    for i, p in enumerate(all_posts[:12]):
        t = (i % 6) + 1
        tcls = "" if t == 1 else f" t{t}"
        cards += f"""<article class="post-card">
  <div class="post-thumb{tcls}">{escape(p['label'][:2].upper())}</div>
  <div class="post-body">
    <span class="post-label">{escape(p['label'])}</span>
    <h3><a href="/blog/posts/{p['slug']}.html">{escape(p['title'])}</a></h3>
    <p>{escape(p['title'])} — practical tips and strategies for creators.</p>
    <div class="post-meta"><span>{p['published'][:10]}</span><span class="dot"></span><span>{p['read']} min read</span></div>
  </div>
</article>"""

    labels_count = {}
    for p in all_posts:
        labels_count[p["label"]] = labels_count.get(p["label"], 0) + 1
    archive_html = "".join(
        f'<li><a href="#{slugify(l)}">{escape(l)}<span>{c}</span></a></li>'
        for l, c in labels_count.items()
    )

    popular_html = "".join(
        f'<div class="popular-item"><span class="popular-num">{i+1}</span><a href="/blog/posts/{p["slug"]}.html">{escape(p["title"])}</a></div>'
        for i, p in enumerate(all_posts[:5])
    )

    grouped = {}
    for p in all_posts:
        grouped.setdefault(p["label"], []).append(p)
    all_html = ""
    for label, posts in grouped.items():
        all_html += f'<h3 id="{slugify(label)}" style="font-size:1.15rem;font-weight:700;margin:28px 0 12px;color:var(--ink)">{escape(label)}</h3><ul style="list-style:none;display:flex;flex-direction:column;gap:8px">'
        for p in posts:
            all_html += f'<li><a href="/blog/posts/{p["slug"]}.html" style="font-size:.9rem;color:var(--ink-2);display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px dashed var(--line)">{escape(p["title"])}<span style="color:var(--muted);font-size:.78rem">{p["published"][:10]}</span></a></li>'
        all_html += "</ul>"

    jsonld = json.dumps({
        "@context": "https://schema.org",
        "@type": "Blog",
        "name": "Bio Link Blog",
        "url": url,
        "description": description,
        "publisher": {"@type": "Organization", "name": SITE_NAME, "logo": {"@type": "ImageObject", "url": f"{SITE_URL}/icon-192.png"}},
        "blogPost": [
            {"@type": "BlogPosting", "headline": p["title"], "url": f"{SITE_URL}/blog/posts/{p['slug']}.html", "datePublished": p["published"]}
            for p in all_posts[:20]
        ],
    }, indent=2)

    meta = meta_block(title, description, url, image, all_posts[0]["published"], all_posts[-1]["modified"], "Blog")

    return f"""<!doctype html>
<html lang="en">
<head>
{HEAD_COMMON}
<title>{escape(title)}</title>
<meta name="description" content="{escape(description)}" />
<meta name="keywords" content="bio link blog, creator tips, ai automation, seo, monetization, email marketing, analytics" />
<meta name="author" content="Bio Link Team" />
<link rel="canonical" href="{url}" />
{verification_block()}
{meta}
<script type="application/ld+json">
{jsonld}
</script>
<style>{STYLE}</style>
</head>
<body>
{HEADER_HTML}

<section class="hero-blog">
  <div class="wrap">
    <span class="chip" style="background:rgba(255,255,255,.14);color:#a5b4fc">Blog</span>
    <h1 class="serif">Creator tips, AI, SEO &amp; growth</h1>
    <p>100+ articles to help you build a stronger presence online — from link-in-bio basics to advanced automation.</p>
  </div>
</section>

<section>
  <div class="wrap blog-layout">
    <div>
      <div class="post-grid">{cards}</div>
      <div class="ad">Advertisement</div>
      <h2 class="serif" style="font-size:1.6rem;font-weight:700;margin:20px 0 8px">All articles</h2>
      <p style="color:var(--muted);font-size:.9rem;margin-bottom:8px">Browse all {len(all_posts)} posts by category.</p>
      <div id="archive">{all_html}</div>
    </div>
    <aside class="sidebar">
      <div class="widget"><h4>Popular posts</h4>{popular_html}</div>
      <div class="widget"><h4>Archive</h4><ul>{archive_html}</ul></div>
      <div class="widget newsletter">
        <h4>Join the newsletter</h4>
        <p>Get creator tips, product updates, and growth strategies in your inbox.</p>
        <form onsubmit="return false"><input type="email" placeholder="you@example.com" /><button class="btn" type="submit">Subscribe</button></form>
      </div>
      <div class="widget" id="contact">
        <h4>Contact</h4>
        <p style="font-size:.85rem;color:var(--muted);margin-bottom:10px">Questions, feedback, or partnership ideas? We'd love to hear from you.</p>
        <a class="btn btn-outline" href="/contact/" style="width:100%">Contact us</a>
      </div>
      <div class="widget">
        <h4>Follow us</h4>
        <ul>
          <li><a href="https://twitter.com/biolink" target="_blank" rel="noopener">Twitter / X<span>→</span></a></li>
          <li><a href="https://www.instagram.com/biolink" target="_blank" rel="noopener">Instagram<span>→</span></a></li>
          <li><a href="https://www.youtube.com/@biolink" target="_blank" rel="noopener">YouTube<span>→</span></a></li>
          <li><a href="https://www.linkedin.com/company/biolink" target="_blank" rel="noopener">LinkedIn<span>→</span></a></li>
        </ul>
      </div>
    </aside>
  </div>
</section>

{FOOTER_HTML}
{COOKIE_HTML}
{SCRIPT_COMMON}
</body>
</html>"""


# ---------------------------------------------------------------------------
# CLOUDFLARE PAGES SUPPORT FILES
# ---------------------------------------------------------------------------

def write_robots():
    content = f"""User-agent: *
Allow: /

User-agent: Googlebot
Allow: /

User-agent: Mediapartners-Google
Allow: /

Sitemap: {SITE_URL}/sitemap.xml
"""
    with open(os.path.join(PUBLIC_DIR, "robots.txt"), "w", encoding="utf-8") as f:
        f.write(content)


def write_sitemap(all_posts):
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    static_pages = ["", "blog/", "about/", "contact/", "privacy/", "disclaimer/", "terms/", "license/", "ads/"]
    for page in static_pages:
        lines.append(f'<url><loc>{SITE_URL}/{page}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>')
    for p in all_posts:
        lines.append(
            f'<url><loc>{SITE_URL}/blog/posts/{p["slug"]}.html</loc>'
            f'<lastmod>{p["modified"][:10]}</lastmod>'
            f'<changefreq>monthly</changefreq><priority>0.7</priority></url>'
        )
    lines.append("</urlset>")
    with open(os.path.join(PUBLIC_DIR, "sitemap.xml"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def write_manifest():
    manifest = {
        "name": "Bio Link — Your link-in-bio, now with a brain",
        "short_name": "Bio Link",
        "description": "Add your links, share posts, send emails, and let AI greet and guide your visitors.",
        "start_url": "/",
        "scope": "/",
        "display": "standalone",
        "orientation": "portrait",
        "background_color": "#0b1220",
        "theme_color": "#4f46e5",
        "lang": "en",
        "categories": ["business", "productivity", "social"],
        "icons": [
            {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
            {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"},
        ],
        "shortcuts": [
            {"name": "Blog", "url": "/blog/"},
            {"name": "Sign up", "url": "/#signup"},
        ],
    }
    with open(os.path.join(PUBLIC_DIR, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)


def write_service_worker():
    sw = """/* Bio Link service worker — Cloudflare Pages friendly */
const CACHE = 'biolink-v1';
const PRECACHE = ['/', '/blog/', '/manifest.json', '/favicon.svg'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  e.respondWith(
    caches.match(req).then((cached) => {
      const fetchPromise = fetch(req).then((res) => {
        if (res && res.status === 200 && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
"""
    with open(os.path.join(PUBLIC_DIR, "sw.js"), "w", encoding="utf-8") as f:
        f.write(sw)


def write_headers():
    content = """/*
  X-Content-Type-Options: nosniff
  X-Frame-Options: SAMEORIGIN
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), microphone=(), camera=()
  Strict-Transport-Security: max-age=31536000; includeSubDomains; preload

/blog/*
  Cache-Control: public, max-age=3600

/blog/posts/*
  Cache-Control: public, max-age=86400

/assets/*
  Cache-Control: public, max-age=31536000, immutable

/sw.js
  Cache-Control: no-cache

/manifest.json
  Cache-Control: public, max-age=86400
"""
    with open(os.path.join(PUBLIC_DIR, "_headers"), "w", encoding="utf-8") as f:
        f.write(content)


def write_redirects():
    content = """/home / 301
/blog /blog/ 301
/about /about/ 301
/contact /contact/ 301
/privacy /privacy/ 301
/disclaimer /disclaimer/ 301
/terms /terms/ 301
/license /license/ 301
/ads /ads/ 301
"""
    with open(os.path.join(PUBLIC_DIR, "_redirects"), "w", encoding="utf-8") as f:
        f.write(content)


def write_ads_txt():
    content = f"google.com, pub-6718454554209533, DIRECT, f08c47fec0942fa0\n"
    with open(os.path.join(PUBLIC_DIR, "ads.txt"), "w", encoding="utf-8") as f:
        f.write(content)


def write_app_ads_txt():
    content = f"google.com, pub-6718454554209533, DIRECT, f08c47fec0942fa0\n"
    with open(os.path.join(PUBLIC_DIR, "app-ads.txt"), "w", encoding="utf-8") as f:
        f.write(content)


def write_browserconfig():
    content = """<?xml version="1.0" encoding="utf-8"?>
<browserconfig>
  <msapplication>
    <tile>
      <square150x150logo src="/icon-192.png"/>
      <TileColor>#4f46e5</TileColor>
    </tile>
  </msapplication>
</browserconfig>
"""
    with open(os.path.join(PUBLIC_DIR, "browserconfig.xml"), "w", encoding="utf-8") as f:
        f.write(content)


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Generate Bio Link blog for Cloudflare Pages.")
    parser.add_argument("--clean", action="store_true", help="Wipe posts dir first")
    args = parser.parse_args()

    if args.clean and os.path.isdir(POSTS_DIR):
        shutil.rmtree(POSTS_DIR)
    os.makedirs(POSTS_DIR, exist_ok=True)

    all_posts = []
    idx = 0
    base_date = datetime(2024, 1, 1)
    for label in LABELS:
        for title in POST_TITLES[label]:
            idx += 1
            slug = slugify(title)
            published = (base_date + timedelta(days=idx * 3)).strftime("%Y-%m-%dT%H:%M:%S+00:00")
            modified = (base_date + timedelta(days=idx * 3 + 5)).strftime("%Y-%m-%dT%H:%M:%S+00:00")
            body = build_body(title, label, idx)
            all_posts.append({
                "title": title, "label": label, "slug": slug, "body": body,
                "published": published, "modified": modified, "read": read_time(body),
            })

    for p in all_posts:
        slug, html = build_post_page(p["title"], p["label"], p["body"], p["published"], p["modified"], all_posts)
        with open(os.path.join(POSTS_DIR, f"{slug}.html"), "w", encoding="utf-8") as f:
            f.write(html)

    with open(os.path.join(BLOG_DIR, "index.html"), "w", encoding="utf-8") as f:
        f.write(build_index_page(all_posts))

    write_robots()
    write_sitemap(all_posts)
    write_manifest()
    write_service_worker()
    write_headers()
    write_redirects()
    write_ads_txt()
    write_app_ads_txt()
    write_browserconfig()

    print(f"✓ Generated {len(all_posts)} posts across {len(LABELS)} labels")
    print(f"✓ Blog index: {os.path.join(BLOG_DIR, 'index.html')}")
    print(f"✓ Posts dir:  {POSTS_DIR}")
    print(f"✓ Cloudflare Pages files: _headers, _redirects, robots.txt, sitemap.xml, manifest.json, sw.js, ads.txt, app-ads.txt, browserconfig.xml")
    print(f"✓ Output root: {PUBLIC_DIR}")


if __name__ == "__main__":
    main()