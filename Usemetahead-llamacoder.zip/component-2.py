#!/usr/bin/env python3
"""
bloggenerator.py — Auto-generator for the MicroBioLink blog.

Creates 300 posts across 10 labels, one page per post, per-label index
pages, a blog hub, a news feed, a discovery page and an AI tools page.
Also writes blog.json consumed by the React app.

Usage:
    python3 bloggenerator.py
    python3 bloggenerator.py --out ./public --base https://microbiolink.app
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone

ADSENSE_PUB = "ca-pub-6718454554209533"
GOOGLE_VERIFICATIONS = [
    "_cIzXXc36JQpFAdNi1A8HnhUc-5lEb3AxlbNyJiK2ZU",
    "QT96Rd0InOuqkb4s1Wu5BlgGD_pCNOy8CsCtveF1zEA",
    "e1adJE3Uadivc1NAhHfSiG1YcUSbTFCJ0gQ9T4nDj_U",
]
MSVALIDATE = "A6BC1DD96D711E50BC95B39A1FA4C33E"

LABELS = ["SEO", "Marketing", "Tech", "Design", "Business", "AI",
          "Social Media", "Tutorial", "News", "Review"]

TITLES = ["Ultimate Guide to", "10 Tips for", "How to Master", "Beginner's Handbook of",
          "Advanced Strategies in", "The Future of", "Common Mistakes in", "Quick Start with",
          "Deep Dive into", "Why You Need"]

TOPICS = ["Bio Links", "SEO Ranking", "Content Marketing", "Web Design", "AI Tools",
          "Social Growth", "Monetization", "Analytics", "Branding", "Automation"]

AUTHORS = ["Admin", "Sarah K.", "Budi S.", "Maya R.", "John D."]


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    return re.sub(r"-+", "-", text).strip("-")


def head_block(title: str, description: str, canonical: str) -> str:
    verif = "\n".join(
        f'<meta name="google-site-verification" content="{v}" />' for v in GOOGLE_VERIFICATIONS
    )
    return f"""<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>{title}</title>
<meta name="description" content="{description}" />
<meta name="robots" content="index, follow" />
<link rel="canonical" href="{canonical}" />
{verif}
<meta name="msvalidate.01" content="{MSVALIDATE}" />
<meta name="google-adsense-account" content="{ADSENSE_PUB}" />
<meta property="og:title" content="{title}" />
<meta property="og:description" content="{description}" />
<meta property="og:type" content="article" />
<meta property="og:url" content="{canonical}" />
<meta name="twitter:card" content="summary_large_image" />
<link rel="icon" type="image/png" href="/favicon.png" />
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
<link rel="apple-touch-icon" href="/icon-192.png" />
<link rel="manifest" href="/manifest.json" />
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADSENSE_PUB}" crossorigin="anonymous"></script>
<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>
</head>"""


def post_html(post: dict, base: str) -> str:
    canonical = f"{base}/blog/{post['label_slug']}/{post['slug']}/"
    return f"""<!doctype html>
<html lang="en">
{head_block(f"{post['title']} | MicroBioLink Blog", post['excerpt'], canonical)}
<body>
<article>
  <h1>{post['title']}</h1>
  <p><strong>{post['label']}</strong> · By {post['author']}</p>
  <p>{post['excerpt']}</p>
  <div>{post['body']}</div>
</article>
</body>
</html>
"""


def index_html(title: str, description: str, base: str, path: str, items: list) -> str:
    cards = "\n".join(
        f'    <li><a href="{i["url"]}">{i["title"]}</a> <span>{i.get("label", "")}</span></li>'
        for i in items
    )
    return f"""<!doctype html>
<html lang="en">
{head_block(title, description, f"{base}{path}")}
<body>
<main>
  <h1>{title}</h1>
  <p>{description}</p>
  <ul>
{cards}
  </ul>
</main>
</body>
</html>
"""


def write(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def generate(out_dir: str, base: str) -> dict:
    posts = []
    for i in range(300):
        label = LABELS[i % len(LABELS)]
        topic = TOPICS[(i * 3) % len(TOPICS)]
        title = f"{TITLES[i % len(TITLES)]} {topic} #{i + 1}"
        slug = slugify(f"{title}-{i + 1}")
        posts.append({
            "id": f"post-{i}",
            "title": title,
            "label": label,
            "label_slug": slugify(label),
            "slug": slug,
            "excerpt": f"Discover actionable insights about {topic.lower()} in this {label} article.",
            "body": (f"This is a comprehensive {label} article covering everything you need to know. "
                     f"We explore practical techniques, real-world examples, and expert recommendations. "
                     f"Whether you're a beginner or a pro, you'll find value here. ") * 3,
            "author": AUTHORS[i % len(AUTHORS)],
            "published": i % 7 != 0,
            "views": 50 + (i * 37) % 5000,
            "url": f"/blog/{slugify(label)}/{slug}/",
        })

    for p in posts:
        write(os.path.join(out_dir, "blog", p["label_slug"], p["slug"], "index.html"),
              post_html(p, base))

    # per-label index
    for label in LABELS:
        items = [p for p in posts if p["label"] == label]
        write(os.path.join(out_dir, "blog", slugify(label), "index.html"),
              index_html(f"{label} Articles | MicroBioLink Blog",
                         f"{len(items)} articles in the {label} category.",
                         base, f"/blog/{slugify(label)}/", items))

    # blog hub
    write(os.path.join(out_dir, "blog", "index.html"),
          index_html("Blog | MicroBioLink",
                     f"{len(posts)} articles across {len(LABELS)} labels.",
                     base, "/blog/", posts[:60]))

    # news feed (latest published)
    news = [p for p in posts if p["published"]][:40]
    write(os.path.join(out_dir, "news", "index.html"),
          index_html("News | MicroBioLink",
                     "Latest news and updates from the MicroBioLink platform.",
                     base, "/news/", news))

    # discovery page
    write(os.path.join(out_dir, "discovery", "index.html"),
          index_html("Discovery | MicroBioLink",
                     "Discover trending topics, creators and tools.",
                     base, "/discovery/", posts[:50]))

    # AI tools page
    ai_items = [{"title": f"AI Tool {i + 1}", "url": f"/ai-tools/tool-{i + 1}/", "label": "AI"}
                for i in range(20)]
    write(os.path.join(out_dir, "ai-tools", "index.html"),
          index_html("AI Tools | MicroBioLink",
                     "20 AI-powered tools for writing, summarizing, translating and more.",
                     base, "/ai-tools/", ai_items))

    write(os.path.join(out_dir, "blog.json"), json.dumps(posts, indent=2, ensure_ascii=False))
    return {"posts": len(posts), "labels": len(LABELS), "out": out_dir}


def main() -> int:
    ap = argparse.ArgumentParser(description="Generate the MicroBioLink blog.")
    ap.add_argument("--out", default="./public", help="output directory")
    ap.add_argument("--base", default="https://microbiolink.app", help="site base URL")
    args = ap.parse_args()
    r = generate(args.out, args.base)
    print(f"[{datetime.now(timezone.utc).isoformat()}] "
          f"Generated {r['posts']} posts across {r['labels']} labels -> {r['out']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())