#!/usr/bin/env python3
"""
Bio Link — Cloudflare Pages Direct Upload Packager (static-only).

Cloudflare's drag-and-drop uploader rejects projects that contain
TypeScript/JSX source files or a package.json, because it assumes a
build step is required. This script fixes that by packaging ONLY the
static output in ./public — no .ts, .tsx, .jsx, package.json, or
node_modules ever enter the ZIP.

Usage:
    python3 public/blog/generator/upload.py
    python3 public/blog/generator/upload.py --no-build   # skip regeneration

Output:
    biolink-pages.zip   ← drag this into Cloudflare Pages "Upload assets"
"""

import os
import sys
import zipfile
import argparse
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.abspath(os.path.join(HERE, "..", ".."))
ROOT_DIR = os.path.abspath(os.path.join(PUBLIC_DIR, ".."))
ZIP_NAME = "biolink-pages.zip"
ZIP_PATH = os.path.join(ROOT_DIR, ZIP_NAME)

# --- Hard exclusions: anything that makes Cloudflare think a build is needed ---
FORBIDDEN_EXT = {
    ".ts", ".tsx", ".jsx", ".mts", ".cts",
    ".vue", ".svelte", ".astro",
    ".scss", ".sass", ".less", ".styl",
    ".py", ".pyc", ".pyo",
    ".map",
}
FORBIDDEN_FILES = {
    "package.json", "package-lock.json", "pnpm-lock.yaml", "yarn.lock",
    "tsconfig.json", "vite.config.ts", "vite.config.js",
    "next.config.js", "next.config.mjs", "nuxt.config.ts",
    "wrangler.toml", "wrangler.json", "wrangler.jsonc",
    "tailwind.config.js", "tailwind.config.ts", "postcss.config.js",
    ".DS_Store", "Thumbs.db", ".gitignore", ".env",
}
FORBIDDEN_DIRS = {
    "generator", "__pycache__", ".git", "node_modules",
    "src", "app", "pages", "components", "lib", "hooks",
    ".next", ".nuxt", ".svelte-kit", "dist", "build",
}

# --- Required static files that MUST be present in the bundle ---
REQUIRED = [
    "index.html",
    "blog/index.html",
    "_headers",
    "_redirects",
    "robots.txt",
    "sitemap.xml",
    "manifest.json",
    "sw.js",
    "ads.txt",
    "app-ads.txt",
    "browserconfig.xml",
]


def run_generator():
    gen = os.path.join(HERE, "blog.py")
    print(f"→ Running generator: {gen}")
    result = subprocess.run([sys.executable, gen, "--clean"], cwd=ROOT_DIR)
    if result.returncode != 0:
        print("✗ Generator failed.")
        sys.exit(result.returncode)
    print("✓ Generator finished.\n")


def is_forbidden(rel_path):
    """Return True if this file must never enter the deploy bundle."""
    parts = rel_path.replace("\\", "/").split("/")
    if any(p in FORBIDDEN_DIRS for p in parts):
        return True
    name = parts[-1]
    if name in FORBIDDEN_FILES:
        return True
    ext = os.path.splitext(name)[1].lower()
    if ext in FORBIDDEN_EXT:
        return True
    return False


def verify_bundle():
    missing = [r for r in REQUIRED if not os.path.exists(os.path.join(PUBLIC_DIR, r))]
    if missing:
        print("⚠ Missing required files:")
        for m in missing:
            print(f"   - {m}")
        return False
    posts_dir = os.path.join(PUBLIC_DIR, "blog", "posts")
    posts = [f for f in os.listdir(posts_dir) if f.endswith(".html")] if os.path.isdir(posts_dir) else []
    print(f"✓ Bundle verified — {len(posts)} blog posts found.")
    return True


def build_zip():
    if os.path.exists(ZIP_PATH):
        os.remove(ZIP_PATH)

    included = 0
    skipped = []
    total_bytes = 0

    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for root, dirs, files in os.walk(PUBLIC_DIR):
            # Prune forbidden dirs in-place so os.walk never descends into them
            dirs[:] = [d for d in dirs if d not in FORBIDDEN_DIRS]
            for name in files:
                full = os.path.join(root, name)
                rel = os.path.relpath(full, PUBLIC_DIR).replace("\\", "/")
                if is_forbidden(rel):
                    skipped.append(rel)
                    continue
                zf.write(full, rel)
                included += 1
                total_bytes += os.path.getsize(full)

    size_mb = os.path.getsize(ZIP_PATH) / (1024 * 1024)
    print(f"✓ Packaged {included} static files ({total_bytes/1024/1024:.2f} MB raw → {size_mb:.2f} MB zip)")
    if skipped:
        print(f"✓ Excluded {len(skipped)} non-static file(s) (source/build files)")
    print(f"✓ Output: {ZIP_PATH}")
    return included


def audit_zip():
    """Final safety check: confirm no forbidden files slipped into the ZIP."""
    bad = []
    with zipfile.ZipFile(ZIP_PATH, "r") as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            if is_forbidden(info.filename):
                bad.append(info.filename)
    if bad:
        print("\n✗ ZIP contains forbidden files — Cloudflare will reject it:")
        for b in bad[:20]:
            print(f"   - {b}")
        return False
    print("✓ ZIP audit passed — 100% static, no TypeScript, no package.json.")
    return True


def print_instructions():
    print("\n" + "=" * 66)
    print("  CLOUDFLARE PAGES — DRAG & DROP DEPLOY (static-only)")
    print("=" * 66)
    print(f"""
  1. Go to:  https://dash.cloudflare.com/
  2. Workers & Pages → Create → Pages → "Upload assets"
  3. Project name:  microbiolink
  4. Drag this file into the upload box:

        {ZIP_PATH}

  5. Click "Deploy site".
  6. (Optional) Add custom domain: microbiolink.app

  ── Why this works now ──────────────────────────────────────────
  The ZIP contains ONLY static files from ./public.
  No .ts / .tsx / .jsx, no package.json, no node_modules.
  Cloudflare's uploader will NOT ask for a build step.

  ── If you still see "requires a build process" ─────────────────
  You are uploading the wrong folder. Upload the ZIP above,
  NOT the project root. The project root contains React source
  (.tsx) which triggers the build warning.

  ── For Git-based deploys (optional) ────────────────────────────
  Build command:           python3 public/blog/generator/blog.py
  Build output directory:  public
  Environment variable:    PYTHON_VERSION = 3.11
""")


def main():
    parser = argparse.ArgumentParser(description="Package public/ for Cloudflare Pages drag-and-drop (static-only).")
    parser.add_argument("--no-build", action="store_true", help="Skip running the blog generator")
    args = parser.parse_args()

    print("=" * 66)
    print("  Bio Link — Cloudflare Pages Packager (static-only)")
    print("=" * 66 + "\n")

    if not args.no_build:
        run_generator()

    if not verify_bundle():
        print("\n✗ Bundle incomplete — aborting.")
        sys.exit(1)

    build_zip()

    if not audit_zip():
        print("\n✗ Audit failed — aborting.")
        sys.exit(1)

    print_instructions()


if __name__ == "__main__":
    main()