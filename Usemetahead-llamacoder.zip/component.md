# Bio Link — Cloudflare Pages Deploy

## ⚠️ Fix for "This uploader does not yet support projects that require a build process"

That error appears when you drag the **project root** into Cloudflare's uploader.
The root contains React source files (`.tsx`, `.ts`) and `package.json`, so Cloudflare
assumes a build step is required.

**Solution:** upload only the static output. Run the packager:
