#!/usr/bin/env python3
"""
generatorUpload.py
Auto-upload / auto-publish pipeline for MicroBioLink.

Watches a source folder for new bio pages, blog posts and tool bundles,
then "publishes" them by copying into the generated/ tree and updating
the published manifest. Runs entirely locally (no external services).

Usage:
    python3 generatorUpload.py --watch ./inbox --out ./generated
    python3 generatorUpload.py --once  ./inbox --out ./generated
"""

import argparse
import json
import os
import shutil
import sys
import time
from datetime import datetime, timezone

PUBLISHED_MANIFEST = "published.json"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_manifest(out_dir: str) -> dict:
    path = os.path.join(out_dir, PUBLISHED_MANIFEST)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"items": [], "updatedAt": now_iso()}


def save_manifest(out_dir: str, manifest: dict) -> None:
    manifest["updatedAt"] = now_iso()
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, PUBLISHED_MANIFEST), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)


def publish_file(src: str, out_dir: str, manifest: dict) -> dict:
    name = os.path.basename(src)
    kind = "post" if name.endswith((".md", ".txt")) else "page"
    dest_dir = os.path.join(out_dir, "published", kind)
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, name)
    shutil.copy2(src, dest)

    item = {
        "id": f"{kind}-{int(time.time() * 1000)}",
        "name": name,
        "kind": kind,
        "path": os.path.relpath(dest, out_dir),
        "published": True,
        "publishedAt": now_iso(),
    }
    manifest["items"].insert(0, item)
    return item


def scan_once(inbox: str, out_dir: str) -> int:
    if not os.path.isdir(inbox):
        print(f"inbox not found: {inbox}")
        return 0
    manifest = load_manifest(out_dir)
    seen = {i["name"] for i in manifest["items"]}
    count = 0
    for name in sorted(os.listdir(inbox)):
        src = os.path.join(inbox, name)
        if not os.path.isfile(src) or name in seen:
            continue
        item = publish_file(src, out_dir, manifest)
        print(f"✓ published {item['kind']}: {item['name']} -> {item['path']}")
        count += 1
    if count:
        save_manifest(out_dir, manifest)
    return count


def watch(inbox: str, out_dir: str, interval: float = 3.0) -> None:
    print(f"watching {inbox} every {interval}s -> {out_dir} (Ctrl+C to stop)")
    try:
        while True:
            scan_once(inbox, out_dir)
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nstopped.")


def main() -> int:
    ap = argparse.ArgumentParser(description="Auto-upload / auto-publish pipeline.")
    ap.add_argument("inbox", nargs="?", default="./inbox", help="folder to watch")
    ap.add_argument("--out", default="./generated", help="output directory")
    ap.add_argument("--watch", action="store_true", help="keep watching")
    ap.add_argument("--interval", type=float, default=3.0, help="watch interval seconds")
    args = ap.parse_args()

    if args.watch:
        watch(args.inbox, args.out, args.interval)
    else:
        n = scan_once(args.inbox, args.out)
        print(f"[{now_iso()}] published {n} item(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())