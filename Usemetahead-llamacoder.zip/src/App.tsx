import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import {
  Link2, LayoutDashboard, Wrench, FileText, Users, Settings, Plus, Trash2,
  Eye, Copy, Share2, Globe, MousePointerClick, Search, Menu, X,
  Shield, Mail, Info, ScrollText, BadgeCheck, Sparkles, BarChart3, Rocket,
  ExternalLink, Clock, Zap, Smartphone, Monitor, Apple, Download,
  Upload, RefreshCw, Code2, DollarSign, BookOpen, ChevronRight, Activity,
  LogIn, LogOut, UserPlus, Lock, User as UserIcon, Check, Save,
} from "lucide-react";

/* ---------- Google verification & AdSense meta ---------- */
const META_HEAD = [
  ['meta', { name: "google-site-verification", content: "_cIzXXc36JQpFAdNi1A8HnhUc-5lEb3AxlbNyJiK2ZU" }],
  ['meta', { name: "google-site-verification", content: "QT96Rd0InOuqkb4s1Wu5BlgGD_pCNOy8CsCtveF1zEA" }],
  ['meta', { name: "google-site-verification", content: "e1adJE3Uadivc1NAhHfSiG1YcUSbTFCJ0gQ9T4nDj_U" }],
  ['meta', { name: "msvalidate.01", content: "A6BC1DD96D711E50BC95B39A1FA4C33E" }],
  ['meta', { name: "google-adsense-account", content: "ca-pub-6718454554209533" }],
  ['script', { async: "true", src: "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6718454554209533", crossorigin: "anonymous" }],
  ['script', { async: "true", "custom-element": "amp-ad", src: "https://cdn.ampproject.org/v0/amp-ad-0.1.js" }],
  ['link', { rel: "icon", type: "image/png", href: "/favicon.png" }],
  ['link', { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" }],
  ['link', { rel: "apple-touch-icon", href: "/icon-192.png" }],
] as const;

function useMetaHead() {
  useEffect(() => {
    META_HEAD.forEach(([tag, attrs]) => {
      const el = document.createElement(tag as string);
      Object.entries(attrs as Record<string, string>).forEach(([k, v]) => el.setAttribute(k, v));
      document.head.appendChild(el);
    });
  }, []);
}

/* ---------- Types ---------- */
export type BioLink = {
  id: string; title: string; url: string; icon: string; clicks: number;
  published: boolean; createdAt: number;
};
export type Client = {
  id: string; ownerId: string; name: string; handle: string; bio: string; theme: string;
  links: BioLink[]; views: number; published: boolean; createdAt: number; updatedAt: number;
};
export type BlogPost = {
  id: string; title: string; label: string; excerpt: string; body: string;
  author: string; published: boolean; views: number; createdAt: number;
};
export type Tool = { id: string; name: string; category: string; desc: string; icon: string };
export type User = {
  id: string; name: string; email: string; password: string;
  role: "admin" | "client"; createdAt: number;
};

/* ---------- Data generators ---------- */
const TOOL_CATEGORIES = ["SEO", "Text", "Image", "Developer", "Converter", "Security", "Social", "Finance", "Utility", "AI"];
const TOOL_NAMES: Record<string, string[]> = {
  SEO: ["Keyword Density", "Meta Tag Generator", "SERP Preview", "Backlink Checker", "Robots.txt Builder", "Sitemap Generator", "Schema Markup", "Page Speed Audit", "Canonical Helper", "Open Graph Tester"],
  Text: ["Word Counter", "Case Converter", "Lorem Ipsum", "Plagiarism Scan", "Readability Score", "Text Diff", "Remove Duplicates", "Slug Generator", "Markdown Editor", "Grammar Fix"],
  Image: ["Image Compressor", "Resize Image", "Crop Tool", "Format Converter", "Background Remover", "Watermark Adder", "Color Picker", "Favicon Maker", "Image to Base64", "SVG Optimizer"],
  Developer: ["JSON Formatter", "Base64 Encode", "URL Encode", "Regex Tester", "JWT Decoder", "UUID Generator", "Hash Generator", "Cron Parser", "HTML Minifier", "CSS Minifier"],
  Converter: ["Unit Converter", "Currency Converter", "Time Zone", "Number to Words", "Binary Converter", "Hex Converter", "PDF to Word", "Word to PDF", "CSV to JSON", "YAML to JSON"],
  Security: ["Password Generator", "Password Strength", "SSL Checker", "IP Lookup", "DNS Lookup", "Whois Lookup", "Port Scanner", "Encryption Tool", "2FA Generator", "Breach Check"],
  Social: ["Hashtag Generator", "Bio Generator", "Post Scheduler", "Engagement Calc", "Username Check", "Emoji Picker", "QR Generator", "Link Shortener", "UTM Builder", "Social Preview"],
  Finance: ["Loan Calculator", "Compound Interest", "Tax Estimator", "Invoice Maker", "Profit Margin", "Break-even Calc", "ROI Calculator", "Salary Converter", "Tip Calculator", "Mortgage Calc"],
  Utility: ["QR Scanner", "Barcode Gen", "Random Picker", "Stopwatch", "Timer", "Calendar", "Notes", "Todo List", "Clipboard", "Screen Ruler"],
  AI: ["AI Writer", "AI Summarizer", "AI Translator", "AI Chat", "AI Image Gen", "AI Code Helper", "AI SEO Advisor", "AI Caption", "AI Voice", "AI Sentiment"],
};
const TOOL_ICONS = ["Wrench", "Zap", "Sparkles", "Rocket", "Code2", "Shield", "Globe", "Star", "Activity", "BarChart3"];

export function generateTools(): Tool[] {
  const tools: Tool[] = [];
  let i = 0;
  TOOL_CATEGORIES.forEach((cat) => {
    TOOL_NAMES[cat].forEach((name) => {
      tools.push({
        id: `tool-${i++}`,
        name,
        category: cat,
        desc: `${name} — powerful ${cat.toLowerCase()} tool for creators and developers.`,
        icon: TOOL_ICONS[i % TOOL_ICONS.length],
      });
    });
  });
  return tools;
}

const BLOG_LABELS = ["SEO", "Marketing", "Tech", "Design", "Business", "AI", "Social Media", "Tutorial", "News", "Review"];
const BLOG_TITLES = [
  "Ultimate Guide to", "10 Tips for", "How to Master", "Beginner's Handbook of",
  "Advanced Strategies in", "The Future of", "Common Mistakes in", "Quick Start with",
  "Deep Dive into", "Why You Need",
];
const BLOG_TOPICS = ["Bio Links", "SEO Ranking", "Content Marketing", "Web Design", "AI Tools", "Social Growth", "Monetization", "Analytics", "Branding", "Automation"];

export function generateBlogPosts(): BlogPost[] {
  const posts: BlogPost[] = [];
  for (let i = 0; i < 300; i++) {
    const label = BLOG_LABELS[i % BLOG_LABELS.length];
    const title = `${BLOG_TITLES[i % BLOG_TITLES.length]} ${BLOG_TOPICS[(i * 3) % BLOG_TOPICS.length]}`;
    posts.push({
      id: `post-${i}`,
      title: `${title} #${i + 1}`,
      label,
      excerpt: `Discover actionable insights about ${BLOG_TOPICS[(i * 3) % BLOG_TOPICS.length].toLowerCase()} in this ${label} article.`,
      body: `This is a comprehensive ${label} article covering everything you need to know. ` +
        `We explore practical techniques, real-world examples, and expert recommendations. ` +
        `Whether you're a beginner or a pro, you'll find value here. `.repeat(3),
      author: ["Admin", "Sarah K.", "Budi S.", "Maya R.", "John D."][i % 5],
      published: i % 7 !== 0,
      views: Math.floor(Math.random() * 5000) + 50,
      createdAt: Date.now() - i * 3600000,
    });
  }
  return posts;
}

export function generateClients(): Client[] {
  const names = ["Alex Rivera", "Dina Putri", "Marcus Chen", "Sofia Lopez", "Rizky Pratama", "Emma Wilson"];
  const themes = ["indigo", "emerald", "rose", "amber", "teal", "violet"];
  return names.map((name, i) => ({
    id: `client-${i}`,
    ownerId: `seed-user-${i}`,
    name,
    handle: name.toLowerCase().replace(/\s/g, ""),
    bio: `Creator & ${["Designer", "Developer", "Marketer", "Photographer", "Writer", "Musician"][i]}. Sharing my journey.`,
    theme: themes[i],
    views: Math.floor(Math.random() * 20000) + 500,
    published: i % 3 !== 0,
    createdAt: Date.now() - i * 86400000,
    updatedAt: Date.now() - i * 86400000,
    links: [
      { id: `l-${i}-1`, title: "Website", url: "https://example.com", icon: "Globe", clicks: Math.floor(Math.random() * 900) + 20, published: true, createdAt: Date.now() },
      { id: `l-${i}-2`, title: "Instagram", url: "https://instagram.com", icon: "Share2", clicks: Math.floor(Math.random() * 900) + 20, published: true, createdAt: Date.now() },
      { id: `l-${i}-3`, title: "YouTube", url: "https://youtube.com", icon: "Eye", clicks: Math.floor(Math.random() * 900) + 20, published: i % 2 === 0, createdAt: Date.now() },
    ],
  }));
}

export function generateSeedUsers(): User[] {
  return [
    { id: "admin-1", name: "Administrator", email: "admin@microbiolink.app", password: "admin123", role: "admin", createdAt: Date.now() },
    { id: "seed-user-0", name: "Alex Rivera", email: "alex@demo.com", password: "demo123", role: "client", createdAt: Date.now() },
  ];
}

/* ---------- Local storage hook ---------- */
function useLocalState<T>(key: string, initial: T) {
  const [state, setState] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch { return initial; }
  });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(state)); } catch {} }, [key, state]);
  return [state, setState] as const;
}

/* ---------- Shared UI ---------- */
function StatCard({ icon: Icon, label, value, tint }: { icon: any; label: string; value: string | number; tint: string }) {
  return (
    <Card className="border-slate-200/70 shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-5 flex items-center gap-4">
        <div className={`h-11 w-11 rounded-xl grid place-items-center ${tint}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <div className="text-2xl font-bold text-slate-900 leading-none">{value}</div>
          <div className="text-xs text-slate-500 mt-1">{label}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function AdSlot({ label = "Advertisement" }: { label?: string }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/70 p-4 text-center">
      <div className="text-[10px] uppercase tracking-widest text-slate-400 mb-1">{label}</div>
      <div className="text-xs text-slate-500">Google AdSense · ca-pub-6718454554209533</div>
    </div>
  );
}

/* ---------- Auth Page ---------- */
function AuthPage({ onLogin, users, setUsers }: {
  onLogin: (u: User) => void;
  users: User[];
  setUsers: (u: User[]) => void;
}) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<"admin" | "client">("client");

  const submit = () => {
    if (mode === "login") {
      const u = users.find(x => x.email.toLowerCase() === email.toLowerCase() && x.password === password);
      if (!u) { toast.error("Invalid email or password"); return; }
      toast.success(`Welcome back, ${u.name}!`);
      onLogin(u);
    } else {
      if (!name.trim() || !email.trim() || !password.trim()) { toast.error("All fields required"); return; }
      if (users.some(x => x.email.toLowerCase() === email.toLowerCase())) { toast.error("Email already registered"); return; }
      const u: User = { id: `user-${Date.now()}`, name, email, password, role, createdAt: Date.now() };
      setUsers([...users, u]);
      toast.success("Account created! Logging in...");
      onLogin(u);
    }
  };

  const quick = (e: string, p: string) => { setEmail(e); setPassword(p); setMode("login"); };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid md:grid-cols-2 bg-white rounded-3xl shadow-2xl overflow-hidden">
        <div className="hidden md:flex flex-col justify-between bg-gradient-to-br from-indigo-600 to-indigo-800 p-8 text-white relative overflow-hidden">
          <div className="absolute -top-16 -right-16 h-56 w-56 rounded-full bg-white/10 blur-2xl" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-8">
              <div className="h-10 w-10 rounded-xl bg-white/20 grid place-items-center"><Link2 className="h-5 w-5" /></div>
              <span className="font-bold text-xl font-serif">MicroBioLink</span>
            </div>
            <h2 className="text-3xl font-bold font-serif leading-tight">Your links, tools & audience — unified.</h2>
            <p className="text-white/80 mt-4 text-sm">Join thousands of creators building their bio link pages with 100+ tools and 300+ articles.</p>
          </div>
          <div className="relative space-y-3 text-sm">
            <div className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-300" /> Auto-saved bio pages</div>
            <div className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-300" /> Real-time publishing</div>
            <div className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-300" /> Admin & client dashboards</div>
          </div>
        </div>

        <div className="p-8 md:p-10">
          <div className="flex items-center gap-2 mb-6 md:hidden">
            <div className="h-9 w-9 rounded-xl bg-indigo-600 grid place-items-center text-white"><Link2 className="h-4 w-4" /></div>
            <span className="font-bold font-serif">MicroBioLink</span>
          </div>
          <h1 className="text-2xl font-bold font-serif text-slate-900">{mode === "login" ? "Welcome back" : "Create account"}</h1>
          <p className="text-sm text-slate-500 mt-1">{mode === "login" ? "Sign in to your dashboard." : "Start building your bio link page."}</p>

          <div className="space-y-4 mt-6">
            {mode === "register" && (
              <div className="space-y-2">
                <Label>Full Name</Label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input className="pl-9" placeholder="Your name" value={name} onChange={e => setName(e.target.value)} />
                </div>
              </div>
            )}
            <div className="space-y-2">
              <Label>Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input className="pl-9" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input className="pl-9" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />
              </div>
            </div>
            {mode === "register" && (
              <div className="space-y-2">
                <Label>Account Type</Label>
                <Select value={role} onValueChange={(v) => setRole(v as "admin" | "client")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="client">Client — build bio links</SelectItem>
                    <SelectItem value="admin">Admin — manage platform</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            <Button onClick={submit} className="w-full bg-indigo-600 hover:bg-indigo-700 gap-2 h-11">
              {mode === "login" ? <><LogIn className="h-4 w-4" /> Sign In</> : <><UserPlus className="h-4 w-4" /> Create Account</>}
            </Button>
          </div>

          <div className="text-center text-sm text-slate-500 mt-5">
            {mode === "login" ? "Don't have an account? " : "Already have an account? "}
            <button className="text-indigo-600 font-medium hover:underline" onClick={() => setMode(mode === "login" ? "register" : "login")}>
              {mode === "login" ? "Register" : "Sign in"}
            </button>
          </div>

          <Separator className="my-6" />
          <div className="text-xs text-slate-500 mb-2">Quick demo access:</div>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" onClick={() => quick("admin@microbiolink.app", "admin123")} className="gap-1.5">
              <Shield className="h-3.5 w-3.5" /> Admin Demo
            </Button>
            <Button variant="outline" size="sm" onClick={() => quick("alex@demo.com", "demo123")} className="gap-1.5">
              <UserIcon className="h-3.5 w-3.5" /> Client Demo
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Bio Link Public Preview ---------- */
function BioPreview({ client, onClose }: { client: Client; onClose: () => void }) {
  const themeMap: Record<string, string> = {
    indigo: "from-indigo-500 to-indigo-700",
    emerald: "from-emerald-500 to-emerald-700",
    rose: "from-rose-500 to-rose-700",
    amber: "from-amber-500 to-amber-700",
    teal: "from-teal-500 to-teal-700",
    violet: "from-violet-500 to-violet-700",
  };
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className={`bg-gradient-to-br ${themeMap[client.theme] || themeMap.indigo} p-6 text-white relative`}>
          <button onClick={onClose} className="absolute top-4 right-4 h-8 w-8 rounded-full bg-white/20 hover:bg-white/30 grid place-items-center">
            <X className="h-4 w-4" />
          </button>
          <Avatar className="h-20 w-20 border-4 border-white/40 mx-auto">
            <AvatarFallback className="bg-white/20 text-white text-2xl font-bold">
              {client.name.split(" ").map(n => n[0]).join("")}
            </AvatarFallback>
          </Avatar>
          <h2 className="text-center text-xl font-bold mt-3">{client.name}</h2>
          <p className="text-center text-sm text-white/80">@{client.handle}</p>
          <p className="text-center text-sm text-white/90 mt-2">{client.bio}</p>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-5 space-y-3">
            {client.links.filter(l => l.published).map((l) => (
              <a key={l.id} href={l.url} target="_blank" rel="noreferrer"
                className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-400 hover:shadow-md transition-all group">
                <div className="h-9 w-9 rounded-lg bg-slate-100 grid place-items-center group-hover:bg-slate-900 group-hover:text-white transition-colors">
                  <Link2 className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-slate-900">{l.title}</div>
                  <div className="text-xs text-slate-500 truncate">{l.url}</div>
                </div>
                <ExternalLink className="h-4 w-4 text-slate-400" />
              </a>
            ))}
            <AdSlot />
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}

/* ---------- Admin Dashboard ---------- */
function AdminDashboard({ clients, setClients, posts, setPosts, tools, users }: {
  clients: Client[]; setClients: (c: Client[]) => void;
  posts: BlogPost[]; setPosts: (p: BlogPost[]) => void;
  tools: Tool[]; users: User[];
}) {
  const [tab, setTab] = useState("overview");
  const [preview, setPreview] = useState<Client | null>(null);
  const totalViews = clients.reduce((s, c) => s + c.views, 0);
  const totalClicks = clients.reduce((s, c) => s + c.links.reduce((a, l) => a + l.clicks, 0), 0);

  const toggleClientPublish = (id: string) => {
    setClients(clients.map(c => c.id === id ? { ...c, published: !c.published, updatedAt: Date.now() } : c));
    toast.success("Client publish status updated");
  };
  const togglePostPublish = (id: string) => {
    setPosts(posts.map(p => p.id === id ? { ...p, published: !p.published } : p));
    toast.success("Post publish status updated");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900 font-serif">Admin Control Center</h1>
          <p className="text-sm text-slate-500 mt-1">Manage clients, content, users, and platform analytics.</p>
        </div>
        <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 gap-1">
          <Activity className="h-3 w-3" /> Live
        </Badge>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total Clients" value={clients.length} tint="bg-indigo-100 text-indigo-600" />
        <StatCard icon={Eye} label="Total Views" value={totalViews.toLocaleString()} tint="bg-emerald-100 text-emerald-600" />
        <StatCard icon={MousePointerClick} label="Total Clicks" value={totalClicks.toLocaleString()} tint="bg-amber-100 text-amber-600" />
        <StatCard icon={FileText} label="Blog Posts" value={posts.length} tint="bg-rose-100 text-rose-600" />
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-slate-100">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="clients">Clients</TabsTrigger>
          <TabsTrigger value="posts">Blog ({posts.length})</TabsTrigger>
          <TabsTrigger value="users">Users ({users.length})</TabsTrigger>
          <TabsTrigger value="tools">Tools ({tools.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 mt-4">
          <div className="grid lg:grid-cols-3 gap-4">
            <Card className="lg:col-span-2 border-slate-200/70 shadow-sm">
              <CardHeader><CardTitle className="text-base">Top Performing Clients</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {[...clients].sort((a, b) => b.views - a.views).slice(0, 5).map((c) => (
                  <div key={c.id} className="flex items-center gap-3">
                    <Avatar className="h-9 w-9"><AvatarFallback className="bg-slate-900 text-white text-xs">{c.name.split(" ").map(n => n[0]).join("")}</AvatarFallback></Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-slate-900 truncate">{c.name}</div>
                      <Progress value={(c.views / Math.max(totalViews, 1)) * 100} className="h-1.5 mt-1" />
                    </div>
                    <div className="text-sm font-semibold text-slate-700">{c.views.toLocaleString()}</div>
                  </div>
                ))}
              </CardContent>
            </Card>
            <Card className="border-slate-200/70 shadow-sm bg-gradient-to-br from-indigo-50 to-white">
              <CardHeader><CardTitle className="text-base">Platform Health</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs mb-1"><span className="text-slate-600">Published Clients</span><span className="font-semibold">{clients.filter(c => c.published).length}/{clients.length}</span></div>
                  <Progress value={(clients.filter(c => c.published).length / Math.max(clients.length, 1)) * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1"><span className="text-slate-600">Published Posts</span><span className="font-semibold">{posts.filter(p => p.published).length}/{posts.length}</span></div>
                  <Progress value={(posts.filter(p => p.published).length / Math.max(posts.length, 1)) * 100} className="h-2" />
                </div>
                <Separator />
                <div className="flex items-center gap-2 text-xs text-slate-600"><Shield className="h-4 w-4 text-emerald-600" /> All systems operational</div>
              </CardContent>
            </Card>
          </div>
          <AdSlot />
        </TabsContent>

        <TabsContent value="clients" className="mt-4">
          <Card className="border-slate-200/70 shadow-sm">
            <CardContent className="p-0">
              <div className="divide-y divide-slate-100">
                {clients.map((c) => (
                  <div key={c.id} className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors">
                    <Avatar className="h-10 w-10"><AvatarFallback className="bg-indigo-100 text-indigo-700 text-xs font-bold">{c.name.split(" ").map(n => n[0]).join("")}</AvatarFallback></Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-slate-900 text-sm">{c.name} <span className="text-slate-400">@{c.handle}</span></div>
                      <div className="text-xs text-slate-500">{c.links.length} links · {c.views.toLocaleString()} views</div>
                    </div>
                    <Badge variant={c.published ? "default" : "secondary"} className={c.published ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : ""}>
                      {c.published ? "Published" : "Draft"}
                    </Badge>
                    <div className="flex items-center gap-1">
                      <Switch checked={c.published} onCheckedChange={() => toggleClientPublish(c.id)} />
                      <Button size="sm" variant="ghost" onClick={() => setPreview(c)}><Eye className="h-4 w-4" /></Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="posts" className="mt-4">
          <Card className="border-slate-200/70 shadow-sm">
            <CardContent className="p-0">
              <ScrollArea className="h-96">
                <div className="divide-y divide-slate-100">
                  {posts.slice(0, 60).map((p) => (
                    <div key={p.id} className="p-3 flex items-center gap-3 hover:bg-slate-50">
                      <Badge variant="outline" className="text-[10px] shrink-0">{p.label}</Badge>
                      <div className="flex-1 min-w-0 text-sm text-slate-800 truncate">{p.title}</div>
                      <span className="text-xs text-slate-400 shrink-0">{p.views} views</span>
                      <Switch checked={p.published} onCheckedChange={() => togglePostPublish(p.id)} />
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="mt-4">
          <Card className="border-slate-200/70 shadow-sm">
            <CardContent className="p-0">
              <div className="divide-y divide-slate-100">
                {users.map((u) => (
                  <div key={u.id} className="p-4 flex items-center gap-4 hover:bg-slate-50">
                    <Avatar className="h-10 w-10"><AvatarFallback className={`text-xs font-bold ${u.role === "admin" ? "bg-rose-100 text-rose-700" : "bg-indigo-100 text-indigo-700"}`}>{u.name.split(" ").map(n => n[0]).join("")}</AvatarFallback></Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-slate-900 text-sm">{u.name}</div>
                      <div className="text-xs text-slate-500">{u.email}</div>
                    </div>
                    <Badge className={u.role === "admin" ? "bg-rose-100 text-rose-700 hover:bg-rose-100" : "bg-indigo-100 text-indigo-700 hover:bg-indigo-100"}>
                      {u.role}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tools" className="mt-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {tools.slice(0, 24).map((t) => (
              <Card key={t.id} className="border-slate-200/70 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4 flex items-start gap-3">
                  <div className="h-9 w-9 rounded-lg bg-slate-900 text-white grid place-items-center shrink-0"><Wrench className="h-4 w-4" /></div>
                  <div className="min-w-0">
                    <div className="font-medium text-sm text-slate-900 truncate">{t.name}</div>
                    <div className="text-xs text-slate-500">{t.category}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {preview && <BioPreview client={preview} onClose={() => setPreview(null)} />}
    </div>
  );
}

/* ---------- Client Dashboard ---------- */
function ClientDashboard({ clients, setClients, user }: {
  clients: Client[]; setClients: (c: Client[]) => void; user: User;
}) {
  const myClients = clients.filter(c => c.ownerId === user.id);
  const [activeId, setActiveId] = useState(myClients[0]?.id || "");
  const active = myClients.find(c => c.id === activeId) || myClients[0];
  const [newTitle, setNewTitle] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [preview, setPreview] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);

  const createPage = () => {
    const id = `client-${Date.now()}`;
    const handle = `${user.name.toLowerCase().replace(/\s/g, "")}${myClients.length + 1}`;
    const nc: Client = {
      id, ownerId: user.id, name: user.name, handle,
      bio: "Welcome to my bio link page!", theme: "indigo",
      views: 0, published: false, createdAt: Date.now(), updatedAt: Date.now(),
      links: [],
    };
    setClients([...clients, nc]);
    setActiveId(id);
    toast.success("New bio page created & auto-saved");
  };

  if (!active) {
    return (
      <div className="max-w-lg mx-auto text-center py-16">
        <div className="h-16 w-16 rounded-2xl bg-indigo-100 text-indigo-600 grid place-items-center mx-auto mb-4"><Link2 className="h-8 w-8" /></div>
        <h2 className="text-xl font-bold font-serif text-slate-900">No bio page yet</h2>
        <p className="text-sm text-slate-500 mt-2 mb-6">Create your first bio link page. It will be auto-saved as you edit.</p>
        <Button onClick={createPage} className="bg-indigo-600 hover:bg-indigo-700 gap-2"><Plus className="h-4 w-4" /> Create Bio Page</Button>
      </div>
    );
  }

  const update = (patch: Partial<Client>) => {
    setClients(clients.map(c => c.id === active.id ? { ...c, ...patch, updatedAt: Date.now() } : c));
    setSavedAt(Date.now());
  };

  const addLink = () => {
    if (!newTitle.trim() || !newUrl.trim()) { toast.error("Title and URL required"); return; }
    const link: BioLink = { id: `l-${Date.now()}`, title: newTitle, url: newUrl, icon: "Link2", clicks: 0, published: true, createdAt: Date.now() };
    update({ links: [...active.links, link] });
    setNewTitle(""); setNewUrl("");
    toast.success("Link added & published live");
  };
  const removeLink = (id: string) => { update({ links: active.links.filter(l => l.id !== id) }); toast.success("Link removed"); };
  const toggleLink = (id: string) => update({ links: active.links.map(l => l.id === id ? { ...l, published: !l.published } : l) });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900 font-serif">Client Studio</h1>
          <p className="text-sm text-slate-500 mt-1 flex items-center gap-2">
            Build, publish, and share your bio link page.
            {savedAt && <span className="text-emerald-600 flex items-center gap-1 text-xs"><Save className="h-3 w-3" /> Auto-saved {new Date(savedAt).toLocaleTimeString()}</span>}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={activeId} onValueChange={setActiveId}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              {myClients.map(c => <SelectItem key={c.id} value={c.id}>{c.name} · @{c.handle}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={createPage} className="gap-2"><Plus className="h-4 w-4" /> New Page</Button>
          <Button onClick={() => setPreview(true)} className="bg-slate-900 hover:bg-slate-800 gap-2">
            <Eye className="h-4 w-4" /> Preview
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-slate-200/70 shadow-sm">
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Settings className="h-4 w-4" /> Profile</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Display Name</Label><Input value={active.name} onChange={e => update({ name: e.target.value })} /></div>
                <div className="space-y-2"><Label>Handle</Label><Input value={active.handle} onChange={e => update({ handle: e.target.value })} /></div>
              </div>
              <div className="space-y-2"><Label>Bio</Label><Textarea value={active.bio} onChange={e => update({ bio: e.target.value })} rows={2} /></div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Theme</Label>
                  <Select value={active.theme} onValueChange={v => update({ theme: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["indigo", "emerald", "rose", "amber", "teal", "violet"].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Publish Status</Label>
                  <div className="flex items-center gap-3 h-10 px-3 rounded-md border border-slate-200">
                    <Switch checked={active.published} onCheckedChange={v => { update({ published: v }); toast.success(v ? "Published live!" : "Set to draft"); }} />
                    <span className="text-sm text-slate-600">{active.published ? "Live" : "Draft"}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200/70 shadow-sm">
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Link2 className="h-4 w-4" /> Links ({active.links.length})</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-3">
                <Input placeholder="Link title" value={newTitle} onChange={e => setNewTitle(e.target.value)} />
                <Input placeholder="https://..." value={newUrl} onChange={e => setNewUrl(e.target.value)} />
              </div>
              <Button onClick={addLink} className="w-full bg-indigo-600 hover:bg-indigo-700 gap-2"><Plus className="h-4 w-4" /> Add & Publish Link</Button>
              <Separator />
              <div className="space-y-2">
                {active.links.length === 0 && <div className="text-center py-8 text-slate-400 text-sm">No links yet. Add your first one above.</div>}
                {active.links.map(l => (
                  <div key={l.id} className="flex items-center gap-3 p-3 rounded-lg border border-slate-200 hover:border-slate-300 transition-colors">
                    <div className="h-8 w-8 rounded-md bg-slate-100 grid place-items-center"><Link2 className="h-3.5 w-3.5 text-slate-600" /></div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-slate-900 truncate">{l.title}</div>
                      <div className="text-xs text-slate-500 truncate">{l.url}</div>
                    </div>
                    <span className="text-xs text-slate-400 hidden sm:block">{l.clicks} clicks</span>
                    <Switch checked={l.published} onCheckedChange={() => toggleLink(l.id)} />
                    <Button size="sm" variant="ghost" onClick={() => removeLink(l.id)}><Trash2 className="h-4 w-4 text-rose-500" /></Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-slate-200/70 shadow-sm">
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><BarChart3 className="h-4 w-4" /> Analytics</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg bg-indigo-50 p-3"><div className="text-xl font-bold text-indigo-700">{active.views.toLocaleString()}</div><div className="text-xs text-indigo-600">Views</div></div>
                <div className="rounded-lg bg-emerald-50 p-3"><div className="text-xl font-bold text-emerald-700">{active.links.reduce((s, l) => s + l.clicks, 0)}</div><div className="text-xs text-emerald-600">Clicks</div></div>
              </div>
              <div className="text-xs text-slate-500">CTR: {((active.links.reduce((s, l) => s + l.clicks, 0) / Math.max(active.views, 1)) * 100).toFixed(1)}%</div>
            </CardContent>
          </Card>

          <Card className="border-slate-200/70 shadow-sm">
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Share2 className="h-4 w-4" /> Share</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              <div className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <Globe className="h-4 w-4 text-slate-400" />
                <span className="text-xs text-slate-600 truncate flex-1">microbiolink.app/{active.handle}</span>
                <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard?.writeText(`https://microbiolink.app/${active.handle}`); toast.success("Copied!"); }}><Copy className="h-3.5 w-3.5" /></Button>
              </div>
              <Button variant="outline" className="w-full gap-2" onClick={() => toast.success("QR code generated")}><Download className="h-4 w-4" /> Download QR</Button>
            </CardContent>
          </Card>
          <AdSlot />
        </div>
      </div>

      {preview && <BioPreview client={active} onClose={() => setPreview(false)} />}
    </div>
  );
}

/* ---------- Tools Page ---------- */
function ToolsPage({ tools }: { tools: Tool[] }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const filtered = tools.filter(t => (cat === "all" || t.category === cat) && t.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 font-serif">Tools Hub</h1>
        <p className="text-sm text-slate-500 mt-1">{tools.length} free tools for creators, developers, and marketers.</p>
      </div>
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input placeholder="Search tools..." value={q} onChange={e => setQ(e.target.value)} className="pl-9" />
        </div>
        <Select value={cat} onValueChange={setCat}>
          <SelectTrigger className="w-full sm:w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {TOOL_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {filtered.map(t => (
          <Card key={t.id} className="border-slate-200/70 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 text-white grid place-items-center shrink-0"><Zap className="h-4 w-4" /></div>
                <div className="min-w-0">
                  <div className="font-semibold text-sm text-slate-900 truncate">{t.name}</div>
                  <Badge variant="outline" className="text-[10px] mt-1">{t.category}</Badge>
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-3 line-clamp-2">{t.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      {filtered.length === 0 && <div className="text-center py-16 text-slate-400">No tools match your search.</div>}
    </div>
  );
}

/* ---------- Blog Page ---------- */
function BlogPage({ posts }: { posts: BlogPost[] }) {
  const [label, setLabel] = useState("all");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<BlogPost | null>(null);
  const filtered = posts.filter(p => p.published && (label === "all" || p.label === label) && p.title.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 font-serif">Blog</h1>
        <p className="text-sm text-slate-500 mt-1">{posts.filter(p => p.published).length} articles across {BLOG_LABELS.length} labels.</p>
      </div>
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input placeholder="Search articles..." value={q} onChange={e => setQ(e.target.value)} className="pl-9" />
        </div>
      </div>
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex gap-2 pb-2">
          <Button size="sm" variant={label === "all" ? "default" : "outline"} onClick={() => setLabel("all")} className={label === "all" ? "bg-slate-900" : ""}>All</Button>
          {BLOG_LABELS.map(l => (
            <Button key={l} size="sm" variant={label === l ? "default" : "outline"} onClick={() => setLabel(l)} className={label === l ? "bg-slate-900" : ""}>{l}</Button>
          ))}
        </div>
      </ScrollArea>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.slice(0, 30).map(p => (
          <Card key={p.id} className="border-slate-200/70 shadow-sm hover:shadow-md transition-shadow cursor-pointer overflow-hidden" onClick={() => setOpen(p)}>
            <div className="h-28 bg-gradient-to-br from-slate-800 to-slate-900 relative">
              <Badge className="absolute top-3 left-3 bg-white/90 text-slate-900 hover:bg-white/90 text-[10px]">{p.label}</Badge>
            </div>
            <CardContent className="p-4">
              <h3 className="font-semibold text-sm text-slate-900 line-clamp-2">{p.title}</h3>
              <p className="text-xs text-slate-500 mt-2 line-clamp-2">{p.excerpt}</p>
              <div className="flex items-center gap-2 mt-3 text-xs text-slate-400">
                <Clock className="h-3 w-3" /> {new Date(p.createdAt).toLocaleDateString()} · {p.views} views
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      {open && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setOpen(null)}>
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl max-h-[85vh] overflow-hidden flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="p-6 border-b border-slate-100 flex items-start justify-between gap-4">
              <div>
                <Badge variant="outline" className="text-[10px] mb-2">{open.label}</Badge>
                <h2 className="text-xl font-bold text-slate-900 font-serif">{open.title}</h2>
                <p className="text-xs text-slate-500 mt-1">By {open.author} · {new Date(open.createdAt).toLocaleDateString()}</p>
              </div>
              <Button size="sm" variant="ghost" onClick={() => setOpen(null)}><X className="h-4 w-4" /></Button>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-6 space-y-4">
                <p className="text-sm text-slate-700 leading-relaxed">{open.body}</p>
                <AdSlot />
                <p className="text-sm text-slate-700 leading-relaxed">{open.body}</p>
              </div>
            </ScrollArea>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Static Pages ---------- */
function StaticPage({ page }: { page: string }) {
  const content: Record<string, { title: string; icon: any; body: string[] }> = {
    about: { title: "About MicroBioLink", icon: Info, body: [
      "MicroBioLink is a modern bio-link platform empowering creators, businesses, and developers to build beautiful link-in-bio pages.",
      "We combine powerful analytics, 100+ built-in tools, and a full blogging engine into one seamless experience.",
      "Our mission is to make the web more connected — one link at a time.",
    ]},
    contact: { title: "Contact Us", icon: Mail, body: [
      "Have questions, feedback, or partnership inquiries? We'd love to hear from you.",
      "Email: support@microbiolink.app",
      "Business: business@microbiolink.app",
      "We typically respond within 24 hours on business days.",
    ]},
    disclaimer: { title: "Disclaimer", icon: Shield, body: [
      "The information provided by MicroBioLink is for general informational purposes only.",
      "All information is provided in good faith, however we make no representation or warranty of any kind regarding accuracy or completeness.",
      "External links are provided for convenience and do not signify endorsement.",
    ]},
    privacy: { title: "Privacy Policy", icon: Shield, body: [
      "We respect your privacy and are committed to protecting your personal data.",
      "We collect minimal data necessary to operate the platform: account info, usage analytics, and cookies for personalization.",
      "We never sell your personal data to third parties. AdSense may use cookies for personalized advertising.",
      "You may request data deletion at any time by contacting us.",
    ]},
    license: { title: "License", icon: ScrollText, body: [
      "MicroBioLink is released under the MIT License.",
      "You are free to use, modify, and distribute this software with attribution.",
      "Copyright © 2025 MicroBioLink. All rights reserved.",
    ]},
    ads: { title: "Advertising", icon: DollarSign, body: [
      "MicroBioLink is supported by advertising through Google AdSense.",
      "Publisher ID: ca-pub-6718454554209533",
      "We display relevant, non-intrusive ads to keep our tools free for everyone.",
      "For ad inquiries, contact ads@microbiolink.app",
    ]},
    "ads.txt": { title: "ads.txt", icon: FileText, body: [
      "google.com, pub-6718454554209533, DIRECT, f08c47fec0942fa0",
    ]},
    "app-ads.txt": { title: "app-ads.txt", icon: FileText, body: [
      "google.com, pub-6718454554209533, DIRECT, f08c47fec0942fa0",
    ]},
    "open-graph": { title: "Open Graph / JSON Meta", icon: Code2, body: [
      '<meta property="og:title" content="MicroBioLink — Bio Links, Tools & Blog" />',
      '<meta property="og:description" content="Create your bio link, use 100+ tools, read 300+ articles." />',
      '<meta property="og:type" content="website" />',
      '<meta property="og:url" content="https://microbiolink.app" />',
      '<meta property="og:image" content="https://microbiolink.app/og-image.png" />',
      '<meta name="twitter:card" content="summary_large_image" />',
      '<link rel="manifest" href="/manifest.json" />',
    ]},
  };
  const c = content[page] || content.about;
  const Icon = c.icon;
  return (
    <div className="max-w-3xl">
      <div className="flex items-center gap-3 mb-4">
        <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-700 text-white grid place-items-center"><Icon className="h-6 w-6" /></div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 font-serif">{c.title}</h1>
      </div>
      <Card className="border-slate-200/70 shadow-sm">
        <CardContent className="p-6 space-y-4">
          {c.body.map((p, i) => (
            <p key={i} className={page === "ads.txt" || page === "app-ads.txt" || page === "open-graph" ? "font-mono text-xs bg-slate-900 text-emerald-400 p-3 rounded-lg overflow-x-auto" : "text-sm text-slate-700 leading-relaxed"}>{p}</p>
          ))}
          <Separator />
          <AdSlot />
        </CardContent>
      </Card>
    </div>
  );
}

/* ---------- Auto Generator ---------- */
function GeneratorPage({ clients, setClients, posts, setPosts, user }: {
  clients: Client[]; setClients: (c: Client[]) => void;
  posts: BlogPost[]; setPosts: (p: BlogPost[]) => void;
  user: User;
}) {
  const [log, setLog] = useState<string[]>([]);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const run = (task: string) => {
    setRunning(true); setProgress(0); setLog([`> Starting ${task}...`]);
    let p = 0;
    const iv = setInterval(() => {
      p += 20;
      setProgress(p);
      setLog(l => [...l, `[${new Date().toLocaleTimeString()}] ${task} step ${p / 20}/5 complete`]);
      if (p >= 100) {
        clearInterval(iv);
        setRunning(false);
        if (task === "Auto Generate Client") {
          const id = `client-${Date.now()}`;
          setClients([...clients, {
            id, ownerId: user.id, name: `Auto Client ${clients.length + 1}`, handle: `autoclient${clients.length + 1}`,
            bio: "Auto-generated bio link profile.", theme: "teal", views: 0, published: true, createdAt: Date.now(), updatedAt: Date.now(),
            links: [{ id: `l-${Date.now()}`, title: "Website", url: "https://example.com", icon: "Globe", clicks: 0, published: true, createdAt: Date.now() }],
          }]);
          setLog(l => [...l, "✓ Client generated, published & auto-saved"]);
        } else if (task === "Auto Publish Post") {
          const id = `post-${Date.now()}`;
          setPosts([{ id, title: `Auto Generated Post ${posts.length + 1}`, label: BLOG_LABELS[posts.length % 10], excerpt: "Auto-generated article.", body: "Auto-generated content body. ".repeat(10), author: user.name, published: true, views: 0, createdAt: Date.now() }, ...posts]);
          setLog(l => [...l, "✓ Post generated & published live"]);
        } else {
          setLog(l => [...l, "✓ Upload complete — files synced to CDN"]);
        }
        toast.success(`${task} complete`);
      }
    }, 300);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 font-serif">Auto Generator & Upload</h1>
        <p className="text-sm text-slate-500 mt-1">Automate content generation and publishing pipeline.</p>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        {[
          { t: "Auto Generate Client", d: "Create a new bio-link client profile instantly.", i: Users, c: "from-indigo-500 to-indigo-700" },
          { t: "Auto Publish Post", d: "Generate and publish a blog article.", i: FileText, c: "from-emerald-500 to-emerald-700" },
          { t: "Auto Upload Files", d: "Sync assets to CDN storage.", i: Upload, c: "from-amber-500 to-amber-700" },
        ].map(({ t, d, i: Icon, c }) => (
          <Card key={t} className="border-slate-200/70 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-5">
              <div className={`h-11 w-11 rounded-xl bg-gradient-to-br ${c} text-white grid place-items-center mb-3`}><Icon className="h-5 w-5" /></div>
              <div className="font-semibold text-slate-900">{t}</div>
              <p className="text-xs text-slate-500 mt-1 mb-4">{d}</p>
              <Button onClick={() => run(t)} disabled={running} className="w-full bg-slate-900 hover:bg-slate-800 gap-2">
                {running ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Rocket className="h-4 w-4" />} Run
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
      <Card className="border-slate-200/70 shadow-sm">
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Code2 className="h-4 w-4" /> Pipeline Log</CardTitle></CardHeader>
        <CardContent>
          {running && <Progress value={progress} className="mb-4 h-2" />}
          <div className="bg-slate-900 rounded-lg p-4 font-mono text-xs text-emerald-400 h-48 overflow-y-auto">
            {log.length === 0 ? <span className="text-slate-500">$ Waiting for task...</span> : log.map((l, i) => <div key={i}>{l}</div>)}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ---------- Home ---------- */
function HomePage({ clients, posts, tools, go }: { clients: Client[]; posts: BlogPost[]; tools: Tool[]; go: (v: string) => void }) {
  const [preview, setPreview] = useState<Client | null>(null);
  return (
    <div className="space-y-10">
      <section className="rounded-3xl bg-gradient-to-br from-indigo-600 via-indigo-700 to-slate-900 text-white p-8 md:p-12 relative overflow-hidden">
        <div className="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
        <div className="relative max-w-2xl">
          <Badge className="bg-white/15 text-white hover:bg-white/15 mb-4 gap-1"><Sparkles className="h-3 w-3" /> All-in-one creator platform</Badge>
          <h1 className="text-3xl md:text-5xl font-bold font-serif leading-tight">One link. Infinite possibilities.</h1>
          <p className="text-white/80 mt-4 text-sm md:text-base">Build your bio link, access {tools.length}+ tools, publish articles, and grow your audience — all in one place.</p>
          <div className="flex flex-wrap gap-3 mt-6">
            <Button onClick={() => go("client")} className="bg-white text-slate-900 hover:bg-slate-100 gap-2"><Rocket className="h-4 w-4" /> Create Your Bio</Button>
            <Button onClick={() => go("tools")} variant="outline" className="border-white/30 text-white hover:bg-white/10 gap-2"><Wrench className="h-4 w-4" /> Explore Tools</Button>
          </div>
          <div className="flex gap-6 mt-8">
            <div><div className="text-2xl font-bold">{clients.length}</div><div className="text-xs text-white/70">Clients</div></div>
            <div><div className="text-2xl font-bold">{tools.length}</div><div className="text-xs text-white/70">Tools</div></div>
            <div><div className="text-2xl font-bold">{posts.length}</div><div className="text-xs text-white/70">Articles</div></div>
          </div>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold font-serif">Featured Bio Links</h2>
          <Button variant="ghost" size="sm" onClick={() => go("admin")} className="gap-1">View all <ChevronRight className="h-4 w-4" /></Button>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {clients.slice(0, 6).map(c => (
            <Card key={c.id} className="border-slate-200/70 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => setPreview(c)}>
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12"><AvatarFallback className="bg-indigo-100 text-indigo-700 font-bold">{c.name.split(" ").map(n => n[0]).join("")}</AvatarFallback></Avatar>
                  <div className="min-w-0">
                    <div className="font-semibold text-sm truncate">{c.name}</div>
                    <div className="text-xs text-slate-500">@{c.handle}</div>
                  </div>
                  {c.published && <Badge className="ml-auto bg-emerald-100 text-emerald-700 hover:bg-emerald-100 text-[10px]">Live</Badge>}
                </div>
                <p className="text-xs text-slate-500 mt-3 line-clamp-2">{c.bio}</p>
                <div className="flex items-center gap-3 mt-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> {c.views.toLocaleString()}</span>
                  <span className="flex items-center gap-1"><Link2 className="h-3 w-3" /> {c.links.length}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <AdSlot />

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold font-serif">Latest Articles</h2>
          <Button variant="ghost" size="sm" onClick={() => go("blog")} className="gap-1">All posts <ChevronRight className="h-4 w-4" /></Button>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {posts.filter(p => p.published).slice(0, 3).map(p => (
            <Card key={p.id} className="border-slate-200/70 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => go("blog")}>
              <CardContent className="p-5">
                <Badge variant="outline" className="text-[10px] mb-2">{p.label}</Badge>
                <h3 className="font-semibold text-sm line-clamp-2">{p.title}</h3>
                <p className="text-xs text-slate-500 mt-2 line-clamp-2">{p.excerpt}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {preview && <BioPreview client={preview} onClose={() => setPreview(null)} />}
    </div>
  );
}

/* ---------- Main App ---------- */
export default function App() {
  useMetaHead();
  const [tools] = useState<Tool[]>(() => generateTools());
  const [posts, setPosts] = useLocalState<BlogPost[]>("mbl_posts", generateBlogPosts());
  const [clients, setClients] = useLocalState<Client[]>("mbl_clients", generateClients());
  const [users, setUsers] = useLocalState<User[]>("mbl_users", generateSeedUsers());
  const [currentUser, setCurrentUser] = useLocalState<User | null>("mbl_session", null);
  const [view, setView] = useState("home");
  const [mobileNav, setMobileNav] = useState(false);

  const logout = () => { setCurrentUser(null); setView("home"); toast.success("Logged out"); };

  if (!currentUser) {
    return <AuthPage onLogin={setCurrentUser} users={users} setUsers={setUsers} />;
  }

  const isAdmin = currentUser.role === "admin";
  const nav: { id: string; label: string; icon: any }[] = isAdmin
    ? [
        { id: "home", label: "Home", icon: Globe },
        { id: "admin", label: "Admin", icon: LayoutDashboard },
        { id: "tools", label: "Tools", icon: Wrench },
        { id: "blog", label: "Blog", icon: BookOpen },
        { id: "generator", label: "Generator", icon: Rocket },
      ]
    : [
        { id: "home", label: "Home", icon: Globe },
        { id: "client", label: "My Bio", icon: Link2 },
        { id: "tools", label: "Tools", icon: Wrench },
        { id: "blog", label: "Blog", icon: BookOpen },
      ];

  const legalNav = [
    { id: "about", label: "About" }, { id: "contact", label: "Contact" },
    { id: "disclaimer", label: "Disclaimer" }, { id: "privacy", label: "Privacy" },
    { id: "license", label: "License" }, { id: "ads", label: "Ads" },
    { id: "ads.txt", label: "ads.txt" }, { id: "app-ads.txt", label: "app-ads.txt" },
    { id: "open-graph", label: "OG/JSON Meta" },
  ];

  const go = (id: string) => { setView(id); setMobileNav(false); window.scrollTo({ top: 0, behavior: "smooth" }); };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <button onClick={() => go("home")} className="flex items-center gap-2 shrink-0">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-800 grid place-items-center text-white shadow-md">
              <Link2 className="h-5 w-5" />
            </div>
            <span className="font-bold text-lg font-serif tracking-tight">MicroBioLink</span>
          </button>
          <nav className="hidden lg:flex items-center gap-1">
            {nav.map(n => (
              <button key={n.id} onClick={() => go(n.id)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${view === n.id ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"}`}>
                <n.icon className="h-4 w-4" /> {n.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100">
              <Avatar className="h-6 w-6"><AvatarFallback className={`text-[10px] font-bold ${isAdmin ? "bg-rose-100 text-rose-700" : "bg-indigo-100 text-indigo-700"}`}>{currentUser.name.split(" ").map(n => n[0]).join("")}</AvatarFallback></Avatar>
              <span className="text-xs font-medium text-slate-700">{currentUser.name}</span>
              <Badge className={`text-[9px] ${isAdmin ? "bg-rose-100 text-rose-700 hover:bg-rose-100" : "bg-indigo-100 text-indigo-700 hover:bg-indigo-100"}`}>{currentUser.role}</Badge>
            </div>
            <Button size="sm" variant="outline" onClick={logout} className="gap-1.5"><LogOut className="h-3.5 w-3.5" /> <span className="hidden sm:inline">Logout</span></Button>
            <Button size="sm" variant="ghost" className="lg:hidden" onClick={() => setMobileNav(!mobileNav)}>
              {mobileNav ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
        {mobileNav && (
          <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-1">
            {nav.map(n => (
              <button key={n.id} onClick={() => go(n.id)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium flex items-center gap-2 ${view === n.id ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"}`}>
                <n.icon className="h-4 w-4" /> {n.label}
              </button>
            ))}
          </div>
        )}
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {view === "home" && <HomePage clients={clients} posts={posts} tools={tools} go={go} />}
        {view === "admin" && isAdmin && <AdminDashboard clients={clients} setClients={setClients} posts={posts} setPosts={setPosts} tools={tools} users={users} />}
        {view === "client" && !isAdmin && <ClientDashboard clients={clients} setClients={setClients} user={currentUser} />}
        {view === "tools" && <ToolsPage tools={tools} />}
        {view === "blog" && <BlogPage posts={posts} />}
        {view === "generator" && isAdmin && <GeneratorPage clients={clients} setClients={setClients} posts={posts} setPosts={setPosts} user={currentUser} />}
        {["about", "contact", "disclaimer", "privacy", "license", "ads", "ads.txt", "app-ads.txt", "open-graph"].includes(view) && <StaticPage page={view} />}
      </main>

      <footer className="bg-slate-900 text-slate-300 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-10 grid md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="h-8 w-8 rounded-lg bg-indigo-600 grid place-items-center text-white"><Link2 className="h-4 w-4" /></div>
              <span className="font-bold font-serif">MicroBioLink</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">Bio links, 100+ tools, and 300+ articles. Built for creators.</p>
            <div className="flex items-center gap-2 mt-4 text-slate-400">
              <Smartphone className="h-4 w-4" /><Monitor className="h-4 w-4" /><Apple className="h-4 w-4" />
              <span className="text-xs">Web · Android · iOS</span>
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-white mb-3">Platform</div>
            <div className="space-y-2">
              {nav.map(n => <button key={n.id} onClick={() => go(n.id)} className="block text-xs text-slate-400 hover:text-white transition-colors">{n.label}</button>)}
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-white mb-3">Legal</div>
            <div className="space-y-2">
              {legalNav.slice(0, 5).map(l => <button key={l.id} onClick={() => go(l.id)} className="block text-xs text-slate-400 hover:text-white transition-colors">{l.label}</button>)}
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-white mb-3">Resources</div>
            <div className="space-y-2">
              {legalNav.slice(5).map(l => <button key={l.id} onClick={() => go(l.id)} className="block text-xs text-slate-400 hover:text-white transition-colors">{l.label}</button>)}
            </div>
          </div>
        </div>
        <div className="border-t border-slate-800">
          <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
            <span>© 2025 MicroBioLink. MIT License.</span>
            <span className="flex items-center gap-1"><BadgeCheck className="h-3.5 w-3.5 text-emerald-500" /> AdSense: ca-pub-6718454554209533</span>
          </div>
        </div>
      </footer>
    </div>
  );
}